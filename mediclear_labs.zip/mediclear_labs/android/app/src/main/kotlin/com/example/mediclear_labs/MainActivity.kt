package com.example.mediclear_labs

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
