import 'package:flutter/material.dart';

class Coloors{
static const fontcolor= Color.fromARGB(255, 48, 161, 106);

}