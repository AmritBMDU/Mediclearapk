
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mediclear_labs/screens/Eyes_test/screens/eye_test_creen1.dart';
import 'package:mediclear_labs/screens/Eyes_test/screens/eye_test_screen3.dart';
import 'package:mediclear_labs/screens/application_form/screens/form.dart';
import 'package:mediclear_labs/screens/application_form/widgets/drop_down_menu.dart';

import 'package:mediclear_labs/screens/hearing_test/screens/about.dart';
import 'package:mediclear_labs/screens/hearing_test/screens/faqs.dart';


import 'package:mediclear_labs/screens/hearing_test/screens/history_page.dart';
import 'package:mediclear_labs/screens/hearing_test/screens/home_screen.dart';
import 'package:mediclear_labs/screens/login_page/forgot_password.dart';
import 'package:mediclear_labs/screens/login_page/login_toggle_button.dart';
import 'package:mediclear_labs/screens/payment_screen/upi_screen.dart';
import 'package:mediclear_labs/screens/signup_screen/signup.dart';

import 'package:mediclear_labs/screens/splash_screen/splash_screen.dart';
import 'package:mediclear_labs/screens/vng_test/screens/vng_test_screen1.dart';
import 'package:mediclear_labs/widgets.dart/drawer/feedback.dart';
import 'package:mediclear_labs/widgets.dart/drawer/reset_password.dart';



Future<void> main() async {
   WidgetsFlutterBinding.ensureInitialized();

  // Obtain a list of the available cameras on the device.

  runApp(MyApp());

}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(fontFamily: 'Raleway'),
      home:SplashScreen()
    );
  }
}

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;
  final List<Widget> _children = [
    HomeTab(),
    HistoryTab(),
    FaqsTab(),
    AboutTab(),
  ];

  void onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Text(
          'Mediclear',
          style:  GoogleFonts.roboto(
              fontSize: 22, fontWeight: FontWeight.w400, color: Colors.black),
        ),
        centerTitle: true,
      ),
      body: _children[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.blue,
        selectedItemColor: Colors.black,
        unselectedItemColor: Colors.grey,
        selectedLabelStyle: TextStyle(color: Colors.black),
        unselectedLabelStyle: TextStyle(color: Colors.grey),
        currentIndex: _currentIndex,
        onTap: onTabTapped,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(
              Icons.home,
              color: Colors.black,
            ),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.history,
              color: Colors.black,
            ),
            label: 'History',
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.question_answer,
              color: Colors.black,
            ),
            label: 'FAQs',
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.info,
              color: Colors.black,
            ),
            label: 'About',
          ),
        ],
      ),
    );
  }
}




// import 'package:flutter/material.dart';

// void main() {
//   runApp(MyApp());
// }

// class MyApp extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       home: ScreenManager(),
//     );
//   }
// }

// class ScreenManager extends StatefulWidget {
//   @override
//   _ScreenManagerState createState() => _ScreenManagerState();
// }

// class _ScreenManagerState extends State<ScreenManager> {
//   bool isTaskCompleted = false;

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text("Screen Manager"),
//       ),
//       body: Navigator(
//         onGenerateRoute: (routeSettings) {
//           return MaterialPageRoute(
//             builder: (context) => FirstScreen(
//               isTaskCompleted: isTaskCompleted,
//               onTaskCompleted: () {
//                 setState(() {
//                   isTaskCompleted = true;
//                 });
//               },
//             ),
//           );
//         },
//       ),
//     );
//   }
// }

// class FirstScreen extends StatefulWidget {
//   final bool isTaskCompleted;
//   final VoidCallback onTaskCompleted;

//   const FirstScreen({
//     Key? key,
//     required this.isTaskCompleted,
//     required this.onTaskCompleted,
//   }) : super(key: key);

//   @override
//   _FirstScreenState createState() => _FirstScreenState();
// }

// class _FirstScreenState extends State<FirstScreen> {
//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       alignment: Alignment.center,
//       child: AnimatedOpacity(
//         opacity: widget.isTaskCompleted ? 0.5 : 1.0,
//         duration: Duration(milliseconds: 500),
//         child: ElevatedButton(
//           onPressed: () {
//             widget.onTaskCompleted();
//             Navigator.of(context).push(
//               MaterialPageRoute(
//                 builder: (context) => SecondScreen(),
//               ),
//             );
//           },
//           style: ElevatedButton.styleFrom(
//             primary: Colors.blue,
//           ),
//           child: Text("Start"),
//         ),
//       ),
//     );
//   }
// }

// class SecondScreen extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       alignment: Alignment.center,
//       child: ElevatedButton(
//         onPressed: () {
//           Navigator.of(context).push(
//             MaterialPageRoute(
//               builder: (context) => ThirdScreen(),
//             ),
//           );
//         },
//         child: Text("Next"),
//       ),
//     );
//   }
// }

// class ThirdScreen extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       alignment: Alignment.center,
//       child: ElevatedButton(
//         onPressed: () {
//           // Perform any final actions here
//           ScaffoldMessenger.of(context).showSnackBar(
//             SnackBar(
//               content: Text("Task completed!"),
//             ),
//           );

//           // Navigate back to the first screen after a delay
//           Future.delayed(Duration(milliseconds: 500), () {
//             Navigator.of(context).popUntil(ModalRoute.withName('/'));
//           });
//         },
//         child: Text("Done"),
//       ),
//     );
//   }
// }


// import 'package:flutter/material.dart';

// void main() {
//   runApp(MyApp());
// }

// class MyApp extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       home: MyForm(),
//     );
//   }
// }

// class MyForm extends StatefulWidget {
//   @override
//   _MyFormState createState() => _MyFormState();
// }

// class _MyFormState extends State<MyForm> {
//   TextEditingController _controller = TextEditingController();
//   List<String> _suggestions = ["Item 1", "Item 2", "Item 3", "Item 4", "Item 5"];
//   List<String> _filteredSuggestions = [];

//   @override
//   void initState() {
//     super.initState();
//     _filteredSuggestions.addAll(_suggestions);
//   }

//   void _filterSuggestions(String input) {
//     setState(() {
//       _filteredSuggestions = _suggestions
//           .where((item) => item.toLowerCase().contains(input.toLowerCase()))
//           .toList();
//     });
//   }

//   void _onSuggestionSelected(String suggestion) {
//     setState(() {
//       _controller.text = suggestion;
//     });
//     // Do something with the selected value
//     print("Selected: $suggestion");
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Dropdown with Search'),
//       ),
//       body: Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.stretch,
//           children: [
//             TextField(
//               controller: _controller,
//               onChanged: (value) {

//                 _filterSuggestions(value);
              

//               },
//               decoration: InputDecoration(
//                 hintText: 'Type to search or select',
//                 contentPadding: EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 10.0),
//                 filled: true,
//                 fillColor: Colors.grey[200],
//               ),
//             ),
//             SizedBox(height: 10),
//             Visibility(
//               visible: _filteredSuggestions.isNotEmpty,
//               child: Container(
//                 decoration: BoxDecoration(
//                   border: Border.all(color: Colors.grey),
//                   borderRadius: BorderRadius.circular(8.0),
//                 ),
//                 child: ListView.builder(
//                   shrinkWrap: true,
//                   itemCount: _filteredSuggestions.length,
//                   itemBuilder: (context, index) {
//                     return ListTile(
//                       title: Text(_filteredSuggestions[index]),
//                       onTap: () {
//                         _onSuggestionSelected(_filteredSuggestions[index]);
//                       },
//                     );
//                   },
//                 ),
//               ),
//             ),
//             // Rest of your form content goes here
//             Text('Other Form Fields'),
//           ],
//         ),
//       ),
//     );
//   }

//    Future<void> _showSignatureDialog() async {
//     return showDialog<void>(
//       context: context,
//       builder: (BuildContext context) {
      

//         return AlertDialog(
          
//           shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10),),
//           // title: new RotationTransition(
//           //   turns: new AlwaysStoppedAnimation(90/360),
//           //   child: const Text('Sign Here',style: TextStyle(
//           //     color: Coloors.fontcolor
//           //   ),),
//           // ),
        
//           actions: [
//              ListView.builder(
//                   shrinkWrap: true,
//                   itemCount: _filteredSuggestions.length,
//                   itemBuilder: (context, index) {
//                     return ListTile(
//                       title: Text(_filteredSuggestions[index]),
//                       onTap: () {
//                         _onSuggestionSelected(_filteredSuggestions[index]);
//                       },
//                     );
//                   },
//                 ),

//           ],
          
        
//         );
//       },
//     );
//   }
// }

