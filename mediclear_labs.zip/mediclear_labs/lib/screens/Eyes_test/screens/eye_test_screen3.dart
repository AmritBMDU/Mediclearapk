import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mediclear_labs/constants/colors.dart';
import 'package:mediclear_labs/screens/hearing_test/screens/vertigo_test.dart';
import 'package:mediclear_labs/screens/login_page/login_page1.dart';



class EyeTestScreen3 extends StatefulWidget {
   EyeTestScreen3({super.key,required this.question_no,required this.image});
  late int question_no;
  late String image;

  @override
  State<EyeTestScreen3> createState() => _EyeTestScreen3State();
}

class _EyeTestScreen3State extends State<EyeTestScreen3> {
  @override
  Widget build(BuildContext context) {
    return EyeTest(context, 1,"assets/color_blindness.png", (){
     Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (ctx)=>EyeTestScreen4()));
                      
    },
    (){
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (ctx)=>EyeTestScreen4()));
                      
    }
    );
  }
}

class EyeTestScreen4 extends StatefulWidget {
  const EyeTestScreen4({super.key});

  @override
  State<EyeTestScreen4> createState() => _EyeTestScreen4State();
}

class _EyeTestScreen4State extends State<EyeTestScreen4> {
  @override
  Widget build(BuildContext context) {
    return EyeTest(context, 1,"assets/eye_blindness3.png", (){
      Navigator.push(context, MaterialPageRoute(builder:(context) => VertigoTest(val1: 2,),)); 
    },(){
      Navigator.push(context, MaterialPageRoute(builder:(context) => VertigoTest(val1: 2,),)); 
    });
  }
}


Widget EyeTest(context, int question_no,String image, final  Function()? onpressed, final  Function()? ontap)
{
  return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Text("Q. ${question_no}/4",style: GoogleFonts.poppins(fontSize: 24,color: Colors.black),),
        centerTitle: true,
        elevation: 0,
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        
        children: [
          Center(child: Text("What do you see in this image?",style: GoogleFonts.poppins(),)),
          CircleAvatar(
            radius:100,
            backgroundColor: Colors.white,
            backgroundImage: AssetImage(image),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              CircleAvatar(
                backgroundColor:Colors.grey.shade400,
                radius: 30,
                child: Text("1"),
              ),
                InkWell(
                  onTap: ontap,
                  child: CircleAvatar(
                  backgroundColor: Colors.grey.shade400,
                  radius: 30,
                  child: Text("74"),
                              ),
                ),
                CircleAvatar(
                  radius: 30,
                backgroundColor:Colors.grey.shade400,
                child: Text("6"),
              ),
             
            ],
          ),
           Container(
                width: 350,
                child: ElevatedButton(onPressed:onpressed,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Coloors.fontcolor
                ), 
                child: Text("Next",style: GoogleFonts.poppins(),)),
              )

        ],
      ),
    );
}


class FinalEyeTestScreen extends StatelessWidget {
  const FinalEyeTestScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Text("Result",style: GoogleFonts.poppins(color: Coloors.fontcolor,fontSize: 24),),
        centerTitle: true,
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.start,
        
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 100),
            child: Container(
              height: 110,
             
            child: Center(child: Image.asset("assets/eye_icon3.png"))),

          
          ),
          SizedBox(
            height: 70,
          ),
          CircleAvatar(
            backgroundColor: Colors.grey.shade200,
               radius: 70,
               
            child: Text("90%",style: GoogleFonts.poppins(fontSize: 20),),
          ),
          SizedBox(
            height: 60,
          ),
          MyButton(name: "Back To Vertigo Test", width: 320, height: 50, onPressedCallback: (){
            Navigator.pushReplacement(context, MaterialPageRoute(builder:(context) => VertigoTest(),));
          })
        ],
      ),
    );
  }
}