import 'dart:io';


import 'package:camera/camera.dart';
import 'package:dropdown_textfield/dropdown_textfield.dart';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mediclear_labs/constants/colors.dart';
import 'package:mediclear_labs/main.dart';
import 'package:mediclear_labs/screens/application_form/widgets/datetime.dart';
import 'package:mediclear_labs/screens/application_form/widgets/drop_down_menu.dart';
import 'package:mediclear_labs/screens/application_form/widgets/notification.dart';
import 'package:mediclear_labs/screens/login_page/login_toggle_button.dart';
import 'package:mediclear_labs/screens/payment_screen/upi_screen.dart';
import 'package:mediclear_labs/screens/test_options.dart';
import 'package:mediclear_labs/screens/hearing_test/screens/vertigo_test.dart';
import 'package:mediclear_labs/widgets.dart/camera.dart';
import 'package:mediclear_labs/screens/application_form/widgets/galary_signature.dart';
import 'package:mediclear_labs/screens/application_form/widgets/geneder_checkbox.dart';
import 'package:mediclear_labs/screens/application_form/widgets/past_medical_history.dart';
import 'package:mediclear_labs/screens/application_form/widgets/phone_number_enter.dart';
import 'package:mediclear_labs/widgets.dart/drawer/payment_history.dart';
import 'package:mediclear_labs/widgets.dart/drawer/feedback.dart';
import 'package:mediclear_labs/widgets.dart/drawer/reset_password.dart';
import 'package:mediclear_labs/widgets.dart/drawer/terms_conditions.dart';
import 'package:mediclear_labs/widgets.dart/drawer/test_history.dart';
import 'package:mediclear_labs/widgets.dart/drawer/user_profile.dart';
import 'package:mediclear_labs/widgets.dart/legal.dart';
import 'package:mediclear_labs/widgets.dart/signature.dart';
import 'package:signature/signature.dart';
import 'package:url_launcher/url_launcher.dart';

class MyForm extends StatefulWidget {
  @override
  _MyFormState createState() => _MyFormState();
}

class _MyFormState extends State<MyForm> {
   final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  TextEditingController nameController = TextEditingController();
  TextEditingController clientAdhharController = TextEditingController();
  TextEditingController companyController = TextEditingController();
  TextEditingController locationController = TextEditingController();
  TextEditingController clientAccountController = TextEditingController();
  TextEditingController genderController = TextEditingController();
  TextEditingController batchController = TextEditingController();
  bool question1 = false;
  bool question2 = false;
  bool question3 = false;
  bool question4 = false;
  bool question5 = false;
  bool question6 = false;
  bool question7 = false;
  bool question8 = false;
   bool questionn1 = false;
  bool questionn2 = false;
  bool questionn3 = false;
  bool questionn4 = false;
  bool questionn5 = false;
  bool questionn6 = false;
  bool questionn7 = false;
  bool questionn8 = false;
  bool pastquestion1 = false;
  bool pastquestion2 = false;
  bool pastquestion3 = false;
  bool pastquestion4 = false;
  bool pastquestion5 = false;
   bool termsAccepted = false;
  

  late String name = "";
    _makingPhoneCall() async {
var url = Uri.parse("tel:9667371301");
if (await canLaunchUrl(url)) {
	await launchUrl(url);
} else {
	throw 'Could not launch $url';
}
}

    Future<void> _showSignatureDialog() async {
    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);

        return AlertDialog(
          
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10),),
          // title: new RotationTransition(
          //   turns: new AlwaysStoppedAnimation(90/360),
          //   child: const Text('Sign Here',style: TextStyle(
          //     color: Coloors.fontcolor
          //   ),),
          // ),
          actions: [
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Coloors.fontcolor
                  ),
                  onPressed: () {
               
                  setState(() {

                    _controller.clear();
                     _signatureBytes = null;
                      
                  });
                          //Navigator.of(context).pop();
                  },
                  child: const Text('Clear'),
                ),
              ElevatedButton(

                 style: ElevatedButton.styleFrom(
                backgroundColor: Coloors.fontcolor
              ),
              onPressed: () {
            
               setState(() {
                 _controller.undo();
               });
              },
              child: const Text('undo'),
                        ),
            ElevatedButton(
               style: ElevatedButton.styleFrom(
                backgroundColor: Coloors.fontcolor
              ),
              onPressed: () {
                              SystemChrome.setPreferredOrientations([
              DeviceOrientation.portraitUp,
              DeviceOrientation.portraitDown,
            ]);
                _controller.toPngBytes().then((signatureBytes) {
                  setState(() {
                    _signatureBytes = signatureBytes;
                  });
                  Navigator.of(context).pop();
                });
              },
              child: const Text('Done'),
            ),
          ],
          content: Container(
            height: 200,
          
            width: 1000,
            child: Signature(
              controller: _controller,
              height: 200,
              width: 1000,
              backgroundColor: Colors.grey.shade300,
            ),
          ),
        
        );
      },
    );
  }

   void _showTermsAndConditionsDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Terms and Conditions'),
          content: SingleChildScrollView(
            child: Column(
              children: [
                Text(
                  '1. Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
                ),
                Text(
                  '2. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                ),
                Text(
                  '3. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.',
                ),
                // Add more terms and conditions as needed
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Close'),
            ),
            ElevatedButton(
              onPressed: () {
                setState(() {
                   termsAccepted = true; // Set termsAccepted to true on Accept
                });
                Navigator.of(context).pop(); // Close the dialog
              },
              child: Text('Accept'),
            ),
          ],
        );
      },
    );
  }
  //  dynamic _showCompanyDailog(BuildContext context)
  //  {
  //  showDialog(context: context, builder:(context) {
  //    return AlertDialog(
  //               elevation: 4.0,
  //               content: ListView.builder(
  //                 padding: EdgeInsets.zero,
  //                 itemCount: _matchingOptions.length,
  //                 shrinkWrap: true,
  //                 itemBuilder: (context, index) {
  //                   return ListTile(
  //                     title: Text(_matchingOptions[index]),
  //                     onTap: () {
  //                       _controllers.text = _matchingOptions[index];
  //                       setState(() {
  //                         _showOverlay = false;
  //                       });
  //                     },
  //                   );
  //                 },
  //               ),
  //             );
  //  },);
  //  }
   String _typedText = '';
//  void _updateMatchingOptions() {
//     setState(() {
//       _matchingOptions = _options
//           .where((option) =>
//               option.toLowerCase().contains(_typedText.toLowerCase()))
//           .toList();
//     });
//   }

//   void _showDropdownPopup(BuildContext context) {
//     showDialog(
//       context: context,
//       builder: (BuildContext context) {
//         return AlertDialog(
//           title: Text('Select or Type a Company'),
//           content: Container(
//             width: double.maxFinite,
//             child: Column(
//               mainAxisSize: MainAxisSize.min,
//               children: [
//                 if (_matchingOptions.isNotEmpty)
//                   ListView.builder(
//                     itemCount: _matchingOptions.length,
//                     shrinkWrap: true,
//                     itemBuilder: (context, index) {
//                       return ListTile(
//                         title: Text(_matchingOptions[index]),
//                         onTap: () {
//                           _controllers.text = _matchingOptions[index];
//                           Navigator.of(context).pop();
//                         },
//                       );
//                     },
//                   )
//                 else
//                   ListView.builder(
//                     itemCount: _options.length,
//                     shrinkWrap: true,
//                     itemBuilder: (context, index) {
//                       return ListTile(
//                         title: Text(_options[index]),
//                         onTap: () {
//                           _controllers.text = _options[index];
//                           Navigator.of(context).pop();
//                         },
//                       );
//                     },
//                   ),
//                 ElevatedButton(
//                   onPressed: () {
//                     Navigator.of(context).pop();
//                   },
//                   child: Text('Select Typed Company'),
//                 ),
//               ],
//             ),
//           ),
//         );
//       },
//     );
//   }

var items = ['Working a lot harder', 'Being a lot smarter', 'Being a self-starter', 'Placed in charge of trading charter'];
  String itemSelected = '';
   TextEditingController _controllers = TextEditingController();
  List<String> _matchingOptions = [];
  bool _showOverlay = false;
    final List<String> _options = ['Option 1', 'Option 2', 'Option 3'];



  @override
  void dispose() {
    nameController.dispose();
    companyController.dispose();
    locationController.dispose();
    clientAccountController.dispose();
    genderController.dispose();
    super.dispose();
  }
   final SignatureController _controller = SignatureController(
    penStrokeWidth: 3,
    penColor: Colors.black,
    exportBackgroundColor: Colors.white,
  );

  Uint8List? _signatureBytes;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
         iconTheme: IconThemeData(color: Colors.black),
        // leading: IconButton(onPressed:() {
          
        // }, icon: Icon(Icons.menu)),
        toolbarHeight: 60,
         backgroundColor: Colors.white,
        title: Text(
          name.length == 0 ? "Saurabh" : name,
          style: const TextStyle(color: Coloors.fontcolor),
        ),
        actions: [
           Padding(
            padding: const EdgeInsets.only(right: 0),
            child: Container(
              height: 80,
              width: 70,
              child: Image.asset("assets/mediclear.jpg"),
            ),
          ),
          IconButton(onPressed:() {
              Navigator.push(context,MaterialPageRoute(builder:(context) => notifcation(),));
          }, icon:Icon(Icons.notification_add_outlined)),
          IconButton(onPressed:() {
           _makingPhoneCall();
          }, icon: Icon(Icons.call_outlined)),
          // Padding(
          //   padding: const EdgeInsets.only(right: 0),
          //   child: Container(
          //     height: 80,
          //     width: 70,
          //     child: Image.asset("assets/mediclear.jpg"),
          //   ),
          // )
        ],
      ),
      drawer:Drawer(
        
       child: ListView(
        // Important: Remove any padding from the ListView.
        padding: EdgeInsets.zero,
        children: [
          SizedBox(
            height: 30,
          ),
           Padding(
             padding: const EdgeInsets.symmetric(vertical: 20,horizontal: 10),
             child: InkWell(
              onTap: (){
                Navigator.push(context, MaterialPageRoute(builder:(BuildContext context)=>User_Profile()));
              },
               child: Container(
                height: 100,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15),
                  color: Coloors.fontcolor
               
                ),
                  child:Padding(
                    padding: const EdgeInsets.only(left: 10),
                    child: Row(crossAxisAlignment: CrossAxisAlignment.center,
                    
                      children: [
                       CircleAvatar(
                            radius: 25,
                            child: Text("SB"),
                            backgroundColor: Colors.grey,
                            
                          ),
                          SizedBox(width: 20,),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                             Text("Hi,Saurabh",style: GoogleFonts.poppins(fontWeight: FontWeight.w400,fontSize: 16,color:Colors.white),),
                             Text("Logged in via 8979034037",style: GoogleFonts.poppins(fontSize: 12,color: Colors.white),) 
                            ],
                          ),
                         
                      ],
                    ),
                  )
                         ),
             ),
             
           ),
       listTile(
                    title: 'Home',
                    icon: Icons.home,
                    callback: (){

                     Navigator.push(context, MaterialPageRoute(builder: (context)=>VertigoTest()));
                    }
                ),
              
          
              listTile(
                  title: ' Test History',
                  icon: Icons.history_outlined,
                  callback: (){
                   Navigator.push(context, MaterialPageRoute(builder: (context)=>TestHistory()));
                  }
              ),
               listTile(
                  title: ' Payment History',
                  icon: Icons.payment_outlined,
                  callback: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>PaymentHistory()));
                  }
              ),
            
              listTile(
                  title: 'Complain & feedback',
                  icon: Icons.message_outlined,
                  callback: (){
                  Navigator.push(context, MaterialPageRoute(builder:(context) => FeedBack(),));
                  }
              ),
              listTile(
                title: 'Reset Password',
                  icon: Icons.password_outlined,
                callback: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>reset_password()));
                }
              ),
             
              listTile(
                title:"Terms & Conditions",
                icon: (Icons.report) ,
                callback: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>termsandCondition()));
                },
              ),
              
              Divider(
                height: 2,
                color: Colors.grey.shade400,
              ),
              listTile(
                  title: 'Logout',
                  icon: Icons.logout_outlined,
                  callback: (){

                      showDialog(
                          context: context,
                          builder: (context){
                            return AlertDialog(
                              title: Text('Alert'),
                              content: Text('Are you sure exit?'),
                              actions: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  children: [
                                    ElevatedButton(onPressed: (){
                                 Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>LoginOptionsToggleButton()));
                                    
                                    }, 
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Coloors.fontcolor
                                    ),
                                    child: Text('Yes')),
                                    ElevatedButton(onPressed: (){
                                      Navigator.pop(context);
                                    }, 
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Coloors.fontcolor
                                    ),
                                    child: Text('No')),
                                  ],
                                )
                              ],
                            );
                          });
                    //  Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>mainPage()));
                  }
              ),
        
        ],
      ),
      
    
    ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          width: 205,
                          child: TextFormField(
                            controller: nameController,
                            decoration: const InputDecoration(hintText: 'Name'),
                            keyboardType: TextInputType.text,
                            // validator: (value) {
                            //   if (value == null || value.isEmpty) {
                            //     return 'Please enter your name';
                            //   }
                            //   return null;
                            // },
                          ),
                        ),
                       Column(
                         children: [
                           Container(
                              width: 205,

                              child:      
                                    TextFormField(
                                      controller: batchController,
                                      decoration: const InputDecoration(hintText: 'Batch number'),
                                      keyboardType: TextInputType.number,
                  //                     validator: (value) {
                  //                       if (value == null || value.isEmpty) {
                  // return 'Please enter your company';
                  //                       }
                  //                       return null;
                  //                     },
                                    ), 
                //               child: DropDownTextField(
                //                   clearOption: false,
                //  controller: companyController,
                //   // searchAutofocus: true,
                //   dropDownItemCount: 8,
                //   searchShowCursor: false,
                //   enableSearch: true,
                //                 dropDownList:
                                
                //                 )
      //                        child:  DropdownSearch<String>(
      //   items: countriesList,
      //   popupProps: PopupProps.menu(
      //     showSearchBox: true,
      //   ),
      //   dropdownButtonProps: DropdownButtonProps(color: Colors.blue,),
      //   dropdownDecoratorProps: DropDownDecoratorProps(
      //     textAlignVertical: TextAlignVertical.center,
      //     dropdownSearchDecoration: InputDecoration(
      //         border: OutlineInputBorder(
      //       borderRadius: BorderRadius.circular(50),
      //     )),
      //   ),
      //   onChanged: (value) {
      //     setState(() {
      //       itemSelected = value.toString();
      //     });
      //   },
      //   selectedItem: itemSelected,
      // ),
                            ),
                         ],
                       ),
                      ],
                    ),
                  const CameraPermission()
                  ],
                ),

                 
                  //                   TextFormField(
                  //                     controller: batchController,
                  //                     decoration: const InputDecoration(hintText: 'Batch number'),
                  //                     keyboardType: TextInputType.number,
                  // //                     validator: (value) {
                  // //                       if (value == null || value.isEmpty) {
                  // // return 'Please enter your company';
                  // //                       }
                  // //                       return null;
                  // //                     },
                  //                   ),
                                     TextField(
  controller: companyController,
  decoration: InputDecoration(
    hintText: "Company",
    suffixIcon: PopupMenuButton<String>(
      icon: const Icon(Icons.arrow_drop_down),
      onSelected: (String value) {
        companyController.text = value;
      },
      itemBuilder: (BuildContext context) {
        return items
            .map<PopupMenuItem<String>>((String value) {
          return new PopupMenuItem(
              child: new Text(value), value: value);
        }).toList();
      },
    ),
  ),

),
              
                TextFormField(
                  controller: locationController,
                  decoration: const InputDecoration(hintText: 'Location',
                 
                  ),
                  // validator: (value) {
                  //   if (value == null || value.isEmpty) {
                  //     return 'Please enter your location';
                  //   }
                  //   return null;
                  // },
                ),
                  
                const SizedBox(
                  height: 5,
                ),
                PhoneNumberInput(),

                DateTimer(),
            
                TextFormField(
                  controller: clientAdhharController,
                  decoration: InputDecoration(
                    hintText: "Adhhar Number"
                  ),
                  // decoration: const InputDecoration(labelText: 'Addhar Number'),
                  keyboardType: TextInputType.number,
                  maxLength: 12,
                  // validator: (value) {
                  //   if (value == null || value.isEmpty || value.length != 12) {
                  //     return 'Please enter valid Addhar number details';
                  //   }
                  //   return null;
                  // },
                ),
                
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      "Gender",
                    ),
                    GenderSelection(),
                  ],
                ),

                const SizedBox(height: 25.0),
                 Text(
                  'To be filled by the candidate before Medical Examination:',
                  style:GoogleFonts.poppins(
                      color: Colors.black, fontWeight: FontWeight.bold,fontSize: 17),
                  textAlign: TextAlign.start,
                ),
                const SizedBox(
                  height: 10,
                ),
                 Text(
                  ' A. When you are "dizzy" do you experience any of the following symptoms? (check yes or no)',
                  textAlign: TextAlign.start,
                  style: GoogleFonts.poppins(color: Colors.black,fontSize: 15),
                ),
                const SizedBox(
                  height: 10,
                ),
                     Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                         // SizedBox(width: 100,),
                          Text("Yes",style: GoogleFonts.poppins(fontSize: 15),),
                          SizedBox(width: 20,),
                          Text("No",style: GoogleFonts.poppins(fontSize: 15),),
                          SizedBox(width: 20,)
                        ],
                      ),
                Container(
                  height: 55,
                  child: Row(
                    children: [
                     
                      Text('1. Light-headedness or swim  \n    sensation in the head?',style: TextStyle(fontSize: 15),),
                       SizedBox(width: 25,),
                       Checkbox(
                    value: question1,
                    onChanged: (value) {
                      setState(() {
                        question1 = value!;
                      });
                    }
              ),
                 Checkbox(
                    value: questionn1,
                    onChanged: (value) {
                      setState(() {
                        questionn1 = value!;
                      });
                    }
              ),
                    ],
                  ),
                  ),
                
               
                  Container(
                    height: 55,
                    child: Row(
                    children: [
                      Text('2. Blacking out or loss of         \n    Consciousness ?',style: TextStyle(fontSize: 15),),
                       SizedBox(width: 25,),
                       Checkbox(
                    value: question2,
                    onChanged: (value) {
                      setState(() {
                        question2 = value!;
                      });
                    }
              ),
                 Checkbox(
                    value: questionn2,
                    onChanged: (value) {
                      setState(() {
                        questionn2 = value!;
                      });
                    }
              ),
                    ],
                  ),
                  ),
                Container(
                  height: 55,
                  child:  Row(
                    children: [
                      Text('3. Object spinning or turning   \n     around you?',style: TextStyle(fontSize: 15),),
                       SizedBox(width: 25,),
                       Checkbox(
                    value: question3,
                    onChanged: (value) {
                      setState(() {
                        question3 = value!;
                      });
                    }
              ),
                 Checkbox(
                    value: questionn3,
                    onChanged: (value) {
                      setState(() {
                        questionn3 = value!;
                      });
                    }
              ),
                    ],
                  ),
                ),
                Container(
                  height: 60, 
                  child: Row(
                    children: [
                      Text('4. Nausea or vomiting               ',style: TextStyle(fontSize:15),),
                       SizedBox(width: 25,),
                       Checkbox(
                    value: question4,
                    onChanged: (value) {
                      setState(() {
                        question4 = value!;
                      });
                    }
              ),
                 Checkbox(
                    value: questionn4,
                    onChanged: (value) {
                      setState(() {
                        questionn4 = value!;
                      });
                    }
              ),
                    ],
                  ),
                ),
                Container(
                  height: 55,
                  child: Row(
                    children: [
                      Text('5. Tingling in your fingers, toes\n     or around your mouth?',style: TextStyle(fontSize: 15),),
                       SizedBox(width: 25,),
                       Checkbox(
                    value: question5,
                    onChanged: (value) {
                      setState(() {
                        question5 = value!;
                      });
                    }
              ),
                 Checkbox(
                    value: questionn5,
                    onChanged: (value) {
                      setState(() {
                        questionn5 = value!;
                      });
                    }
              ),
                    ],
                  ),
                  // child: CheckboxListTile(
                  //   title: const Text(
                  //   '5. Tingling in your fingers, toes or \n     around your mouth?',
                  //  style: TextStyle(
                  //     fontSize: 15
                  //   ),
                  //   textAlign: TextAlign.start),
                  //   value: question5,
                  //   onChanged: (value) {
                  // setState(() {
                  //   question5 = value!;
                  // });
                  //   },
                  // ),
                ),
                Container(
                  height: 55,
                  child: Row(
                    children: [
                      Text('6. Does change of Position       \n     make you dizzy?',style: TextStyle(fontSize: 15),),
                       SizedBox(width: 25,),
                       Checkbox(
                    value: question6,
                    onChanged: (value) {
                      setState(() {
                        question6= value!;
                      });
                    }
              ),
                 Checkbox(
                    value: questionn6,
                    onChanged: (value) {
                      setState(() {
                        questionn6= value!;
                      });
                    }
              ),
                    ],
                  ),
                ),
                Container(
                  height: 80,
                  child: Row(
                    children: [
                      Text('7. when you are dizzy,must      \n    support yourself when\n    standing?',style: TextStyle(fontSize: 15),),
                       SizedBox(width: 25,),
                       Checkbox(
                    value: question7,
                    onChanged: (value) {
                      setState(() {
                        question7 = value!;
                      });
                    }
              ),
                 Checkbox(
                    value: questionn7,
                    onChanged: (value) {
                      setState(() {
                        questionn7= value!;
                      });
                    }
              ),
                    ],
                  ),
                ),
              
                const SizedBox(
                  height: 10,
                ),
                 PastMedicalHistory(),
                 const SizedBox(
                  height: 15,
                ),
                  const Text(
                  'Complaint:',
                  style: TextStyle(
                      color: Colors.black, fontWeight: FontWeight.bold,fontSize: 17),
                  textAlign: TextAlign.start,
                                ),
                 
                 Complaints(),
             
              

                const SizedBox(height: 20.0),

              

                Column(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                   Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                     children: [
                       Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            ElevatedButton(
              style:ElevatedButton.styleFrom(
                backgroundColor: Coloors.fontcolor
              ),
              onPressed: () {
               setState(() {
                _showSignatureDialog();        
               });
              },
              child: const Text('Sign Here',style: TextStyle(color: Colors.white),),
            ),
            const SizedBox(width: 20),
          
             _signatureBytes != null?
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Container(
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.black,width: 0.5),
                      
                      //borderRadius: BorderRadius.circular(10)
                    ),
                    child: Image.memory(
                      _signatureBytes!,
                      width: 180,
                      height: 40,
                    ),
                  ),
                   Text("Please clear sign to upload from gallery!!",style: TextStyle(fontSize: 12, color: Coloors.fontcolor),)
                ],
              ):GallerySign()
              
          
          ],
        ),
       
         ],
                   ),
        
        const SizedBox(
          height: 25,
        ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        ElevatedButton(onPressed:() {
                          
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Coloors.fontcolor
                        ),
                         child:  Text("Preview",style: GoogleFonts.poppins(color: Colors.white),)),
                        ElevatedButton(
                          onPressed: () {
                            if (_formKey.currentState!.validate()) {
                              print('Name: ${nameController.text}');
                              print('Company: ${companyController.text}');
                              print('Location: ${locationController.text}');
                              print(
                                  'Client Account: ${clientAccountController.text}');
                              print('Gender: ${genderController.text}');
                              print('Question 1: $question1');
                              print('Question 2: $question2');
                              setState(() {
                                name = nameController.text;
                              });
                              //  nameController.clear();
                              //  companyController.clear();
                              //  locationController.clear();
                              //  clientAccountController.clear();

                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => UpiPaymentScreen()),
                              );
                            }
                          },
                          style: ElevatedButton.styleFrom(
                              
                              backgroundColor: Coloors.fontcolor),
                          child: Text('Submit',style: GoogleFonts.poppins(color: Colors.white),),
                        ),
                      ],
                    ),
                  ],
                ),

              ],
            ),
          ),
        ),
      ),
    );
  }
 
}

Widget listTile({String? title, icon, Function()? callback}){
  return ListTile(
    onTap: callback,
    title: Text('$title',style: GoogleFonts.poppins(fontWeight:FontWeight.w300,fontSize:18),),
    leading: Icon(icon,color: Coloors.fontcolor,),
  );
}
