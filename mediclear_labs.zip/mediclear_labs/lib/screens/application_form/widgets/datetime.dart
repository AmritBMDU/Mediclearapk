import 'package:flutter/material.dart';
import 'package:intl/intl.dart';


class DOBWidget extends StatefulWidget {
  @override
  _DOBWidgetState createState() => _DOBWidgetState();
}

class _DOBWidgetState extends State<DOBWidget> {
  final TextEditingController _dobController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Container(
      // width: 150,
      child: TextFormField(
        controller: _dobController,
        maxLength: 10,
        keyboardType: TextInputType.number,
        decoration: InputDecoration(
          // labelText: 'Date of Birth',
          hintText: 'DD/MM/YYYY',
        ),
        style: TextStyle(fontSize: 16), // Customize text style as needed
        onChanged: (value) {
          // Automatically add or remove slashes based on the input
          if (value.length == 2 && !_dobController.text.endsWith('/')) {
            _dobController.text = '$value/';
          } else if (value.length == 5 && !_dobController.text.endsWith('/')) {
            _dobController.text = '$value/';
          } else if (value.length == 2 && _dobController.text.endsWith('/')) {
            _dobController.text = value.substring(0, 1);
          } else if (value.length == 5 && _dobController.text.endsWith('/')) {
            _dobController.text = value.substring(0, 4);
          }
        },
      ),
    );
  }

  void validateAndProcessDOB() {
    final String dobText = _dobController.text;

    if (dobText.length != 10) {
      // Show an error message or handle invalid input
      print('Please enter a valid date.');
      return;
    }

    // Extract day, month, and year from the entered date
    final List<String> dateParts = dobText.split('/');
    final String day = dateParts[0];
    final String month = dateParts[1];
    final String year = dateParts[2];

    // Validate the entered date (you can add more complex validation logic here)
    final isValidDate = isValidDateInput(int.parse(day), int.parse(month), int.parse(year));

    if (isValidDate) {
      // Process the valid DOB
      final dob = DateTime(int.parse(year), int.parse(month), int.parse(day));
      print('Date of Birth: ${DateFormat('yyyy-MM-dd').format(dob)}');
    } else {
      // Show an error message or handle invalid date
      print('Invalid date. Please check your input.');
    }
  }

  bool isValidDateInput(int day, int month, int year) {
    try {
      final DateTime date = DateTime(year, month, day);
      return date.year == year && date.month == month && date.day == day;
    } catch (e) {
      return false;
    }
  }
}
