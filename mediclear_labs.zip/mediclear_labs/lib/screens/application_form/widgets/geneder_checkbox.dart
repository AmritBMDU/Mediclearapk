import 'package:flutter/material.dart';


class GenderSelection extends StatefulWidget {
  @override
  _GenderSelectionState createState() => _GenderSelectionState();
}

class _GenderSelectionState extends State<GenderSelection> {
  bool male = false;
  bool female = false;
  bool others = false;
  //  void submitgender() {
  //   setState(() {
  //     male = false;
  //     female = false;
  //     others = false;
  //   });
  // }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Checkbox(
          value: male,
          onChanged: (bool? value) {
            setState(() {
              male = value!;
              if (male) {
                // Handle male selection
                female = false;
                others = false;
              }
            });
          },
        ),
        Text('Male'),
        Checkbox(
          value: female,
          onChanged: (bool? value) {
            setState(() {
              female = value!;
              if (female) {
               
                male = false;
                others = false;
              }
            });
          },
        ),
        Text('Female'),
        Checkbox(
          value: others,
          onChanged: (bool? value) {
            setState(() {
              others = value!;
              if (others) {
              
                male = false;
                female = false;
              }
            });
          },
        ),
        Text('Others'),
      ],
    );
  }
}
