import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mediclear_labs/constants/colors.dart';



class notifcation extends StatefulWidget {
  const notifcation({super.key});

  @override
  State<notifcation> createState() => _notifcation();
}

class _notifcation extends State<notifcation> {

 


  @override
  Widget build(BuildContext context) {
    String text = 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever since the 1500s,';
  String Date = '14 Oct at 5:40';
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          leading: IconButton(onPressed:() {
            Navigator.pop(context);
          }, icon:Icon(Icons.navigate_before,color: Coloors.fontcolor,)),
          backgroundColor: Colors.white,
          automaticallyImplyLeading: false,
      
          title: Text('Notification',style: GoogleFonts.poppins(color: Coloors.fontcolor,fontWeight: FontWeight.bold),),
          centerTitle: true,
          ),
          
      
      //  backgroundColor: Colors.transparent,
        resizeToAvoidBottomInset: false,
        body: SingleChildScrollView(
        //  color: Colors.blue,
      
                  child: Column(
                    children: [
                   Padding(
                     padding: const EdgeInsets.all(12.0),
                     child: SingleChildScrollView(
                       child: Column(
                         children: [
                           Card(
                            color: Colors.grey[100],
                            elevation: 5,
                            child: ListTile(
      
                              title: Text(text,style: TextStyle(fontSize: 12,)    ,),
                              subtitle: Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  Text(Date,style: TextStyle(fontSize: 12,color: Coloors.fontcolor),),
                                ],
                              ),
                            ),
                             ),
                           SizedBox(height: 5,),
                           Card(
                             color: Colors.grey[100],
                             elevation: 5,
                             child: ListTile(
      
                               title: Text(text,style: TextStyle(fontSize: 12,)    ,),
                               subtitle: Row(
                                 mainAxisAlignment: MainAxisAlignment.end,
                                 children: [
                                   Text(Date,style: TextStyle(fontSize: 12,color: Coloors.fontcolor),),
                                 ],
                               ),
                             ),
                           ),
                           SizedBox(height: 5,),
                           Card(
                             color: Colors.grey[100],
                             elevation: 5,
                             child: ListTile(
      
                               title: Text(text,style: TextStyle(fontSize: 12,)    ,),
                               subtitle: Row(
                                 mainAxisAlignment: MainAxisAlignment.end,
                                 children: [
                                   Text(Date,style: TextStyle(fontSize: 12,color: Coloors.fontcolor),),
                                 ],
                               ),
                             ),
                           ),
                           SizedBox(height: 5,),
                           Card(
                             color: Colors.grey[100],
                             elevation: 5,
                             child: ListTile(
      
                            title: Text(text,style: TextStyle(fontSize: 12,)    ,),
                            subtitle: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Text(Date,style: TextStyle(fontSize: 12,color: Coloors.fontcolor),),
                              ],
                            ),
                             ),
                           ),
                           SizedBox(height: 5,),
                           Card(
                             color: Colors.grey[100],
                             elevation: 5,
                             child: ListTile(
      
                            title: Text(text,style: TextStyle(fontSize: 12,)    ,),
                            subtitle: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Text(Date,style: TextStyle(fontSize: 12,color: Coloors.fontcolor),),
                              ],
                            ),
                             ),
                           ),
                           SizedBox(height: 5,),
                           Card(
                             color: Colors.grey[100],
                             elevation: 5,
                             child: ListTile(
      
                            title: Text(text,style: TextStyle(fontSize: 12,)    ,),
                            subtitle: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Text(Date,style: TextStyle(fontSize: 12,color: Coloors.fontcolor),),
                              ],
                            ),
                             ),
                           ),
                           SizedBox(height: 5,),
                           Card(
                             color: Colors.grey[100],
                             elevation: 5,
                             child: ListTile(
      
                            title: Text(text,style: TextStyle(fontSize: 12,)    ,),
                            subtitle: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Text(Date,style: TextStyle(fontSize: 12,color: Coloors.fontcolor),),
                              ],
                            ),
                             ),
                           ),
                           SizedBox(height: 5,),
                         ],
                       ),
                     )
          )
                    ],
                  ),
        ),
        //floatingActionButton:floatingActionButon(),
      ),
    );
  }
}
Widget floatingActionButon(){
  return    SizedBox(
    height: 40,
    width: 40,
    child: FloatingActionButton(

    backgroundColor: Colors.green,
    onPressed: () {  },child: FaIcon(FontAwesomeIcons.whatsapp,)

    ),
  );
}
