import 'package:flutter/material.dart';




class PhoneNumberInput extends StatefulWidget {
  @override
  _PhoneNumberInputState createState() => _PhoneNumberInputState();
}

class _PhoneNumberInputState extends State<PhoneNumberInput> {
  bool isNAToggled = false;
  TextEditingController phoneNumberController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.center,
     
        children: [
        //  Text("Phone Number",style: TextStyle(fontSize: 16,color: Colors.grey.shade700),),
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
               
                Text('NA'),
                Checkbox(
                 value: isNAToggled,
                 onChanged: (bool? value) {
                   setState(() {
                     isNAToggled = value!;
                     if (isNAToggled) {
                      
                       phoneNumberController.clear();
                      
                     }
                   });
                 },
                            ),
              
              // SizedBox(width: 10),
              Expanded(
               
                child: Visibility(
                  visible: !isNAToggled,
                  child: TextFormField(
                    controller: phoneNumberController,
                    maxLength: 10,
                   decoration: InputDecoration(hintText: 'Phone Number'),
                    keyboardType: TextInputType.phone,
                    // validator: (value) {
                    //   if (value == null || value.isEmpty||value.length!=10) {
                    //     return 'Please enter 10 digit number';
                    //   }
                    //   return null;
                    // },
                  ),
                ),
              ),
             
             
            ],
          ),
         // SizedBox(height: 20),
         
        ],
      
    );
  }
}
