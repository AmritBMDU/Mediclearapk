import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mediclear_labs/constants/colors.dart';
import 'package:mediclear_labs/screens/blood_pressure_test/widgets/switch_button.dart';
import 'package:mediclear_labs/screens/hearing_test/widgets/graph.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

class BloodPressureTestCreen1 extends StatefulWidget {
  const BloodPressureTestCreen1({super.key});

  @override
  State<BloodPressureTestCreen1> createState() => _BloodPressureTestCreen1State();
}

class _BloodPressureTestCreen1State extends State<BloodPressureTestCreen1> {

  @override
  Widget build(BuildContext context) {
     SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);

    return WillPopScope(

      onWillPop: () async{ 
                              SystemChrome.setPreferredOrientations([
                DeviceOrientation.portraitUp,
                DeviceOrientation.portraitDown,
              ]);
              Navigator.pop(context);
              return true;
       },
      child: Scaffold(
         appBar: AppBar(
          title: Text('MEDICLEAR',style: GoogleFonts.roboto(fontSize: 24,fontWeight: FontWeight.bold,color: Colors.white),),
          backgroundColor: Coloors.fontcolor,
            automaticallyImplyLeading: false,
             leading: IconButton(onPressed:() {
                                    SystemChrome.setPreferredOrientations([
                DeviceOrientation.portraitUp,
                DeviceOrientation.portraitDown,
              ]);
              Navigator.pop(context);
            }, icon:Icon(Icons.navigate_before,color: Colors.white,size: 35,)),
          centerTitle: true,
          elevation: 2,
        ),
        body: Row(
          children: [
              Container(
              width: 470,
              child: BloodPressureGraph(),
        
            ),
            Container(
              width: 250,
              child: EarlierPostBloodPressueDetails()),
              
        
          ],
        ),
      ),
    );
  }
}


Widget CustomeTextField(String title,TextEditingController text){
  return TextFormField(
      //   obscureText: true,
      controller: text,
      decoration: InputDecoration(
          hintText: title,
          hintStyle: GoogleFonts.roboto(),
          border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide(color: Color.fromARGB(255, 48, 6, 234))),
          fillColor: Color.fromARGB(255, 228, 226, 239),
          filled: true),
    );
}


class BloodPressureGraph extends StatefulWidget {
   BloodPressureGraph({super.key});
   


  @override
  State<BloodPressureGraph> createState() => _BloodPressureGraphState();
}

class _BloodPressureGraphState extends State<BloodPressureGraph> {
@override
    Widget build(BuildContext context) {
      
         return Scaffold(
            body: Center(
                child: Container(
                    child: SfCartesianChart(
                     //   primaryXAxis: NumericAxis(),
                        series: <ChartSeries>[
                         RangeAreaSeries<ChartData, double>(
            dataSource: <ChartData>[
              ChartData(0, 4, 2),
              ChartData(1, 7, 3),
              ChartData(2, 5, 2),
              ChartData(3, 9, 4),
              ChartData(4, 8, 3),
            ],
            xValueMapper: (ChartData data, _) => data.x,
            highValueMapper: (ChartData data, _) => data.high,
            lowValueMapper: (ChartData data, _) => data.low,
            opacity: 0.5,
            name: 'Range Area',
          ),
                        ]
                    )
                )   
            )
        );
    }
}

  class ChartData {
        ChartData(this.x, this.high, this.low);
            final double x;
            final double high;
            final double low;
    }
