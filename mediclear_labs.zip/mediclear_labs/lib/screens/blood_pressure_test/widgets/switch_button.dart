import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mediclear_labs/constants/colors.dart';
import 'package:mediclear_labs/screens/blood_pressure_test/Screens/blood_pressure_test.dart';
import 'package:mediclear_labs/screens/hearing_test/screens/vertigo_test.dart';

class EarlierPostBloodPressueDetails extends StatefulWidget {
  const EarlierPostBloodPressueDetails({super.key});

  @override
  State<EarlierPostBloodPressueDetails> createState() => _EarlierPostBloodPressueDetailsState();
}

class _EarlierPostBloodPressueDetailsState extends State<EarlierPostBloodPressueDetails> {
    TextEditingController postlower= TextEditingController();
  TextEditingController postupper= TextEditingController();
  TextEditingController preupper= TextEditingController();
  TextEditingController prelower= TextEditingController();
  
   int _currentIndex = 0;
  @override
  Widget build(BuildContext context) {
    return  Column(
        children: [
          // Toggle Button
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
             Text('Pre BP',textAlign: TextAlign.center, style: GoogleFonts.roboto(fontWeight: FontWeight.bold,fontSize:14, color: Coloors.fontcolor),),
             Radio(value: 0, groupValue: _currentIndex, onChanged:(value){
                 setState(() {
                   _currentIndex=value!;
                 });
             }),
             Text('Pre BP',textAlign: TextAlign.center, style: GoogleFonts.roboto(fontWeight: FontWeight.bold,fontSize:14, color: Coloors.fontcolor),),
                Radio(value: 1, groupValue: _currentIndex, onChanged:(value){
                 setState(() {
                   _currentIndex=value!;
                 });
             }),
              
              // Switch(
              //   value: _currentIndex == 0,
              //   onChanged: (value) {
              //     setState(() {
              //       _currentIndex = value ? 0 : 1;
              //     });
              //   },
              // ),
              // Text('Post BP',textAlign: TextAlign.center, style:GoogleFonts.roboto(fontWeight: FontWeight.bold,fontSize:14, color: Coloors.fontcolor),),
            ],
          ),
          // Content based on the selected screen
          IndexedStack(
            index: _currentIndex,
            children: [
              // Screen 1
              buildScreen1Content(),

              // Screen 2
              buildScreen2Content(),
            ],
          ),
        ],
      
    );
  }

  Widget buildScreen1Content() {
    // You can call any widget or UI elements for Screen 1 here
    return Center(
      child: Column(
       // mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          CustomeTextField("Lower BP",prelower ),
          SizedBox(
            height: 20,
          ),
          CustomeTextField("Upper BP", preupper),
          SizedBox(
            height: 20,
          ),
        
        ],
      )
    );
  }

  Widget buildScreen2Content() {
    // You can call any widget or UI elements for Screen 2 here
    return  Center(
      child: Column(
       // mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          CustomeTextField("Lower BP",prelower ),
          SizedBox(
            height: 20,
          ),
          CustomeTextField("Upper BP", preupper),
          SizedBox(
            height: 20,
          ),
          ElevatedButton(onPressed:() {
             SystemChrome.setPreferredOrientations([
              DeviceOrientation.portraitUp,
              DeviceOrientation.portraitDown,
            ]);
            Navigator.push(context, MaterialPageRoute(builder:(context) => VertigoTest(val2: 1,),));
          }, 
            style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                  backgroundColor: Coloors.fontcolor
                ), 
          child:Text("Finish",style: GoogleFonts.roboto(color: Colors.white),))
        ],
      )
    );
  }
}