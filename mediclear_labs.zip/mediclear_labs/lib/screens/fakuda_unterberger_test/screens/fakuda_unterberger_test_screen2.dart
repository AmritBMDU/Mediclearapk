import 'dart:io';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:mediclear_labs/constants/colors.dart';
import 'package:mediclear_labs/screens/hearing_test/screens/vertigo_test.dart';


class FakudaUnterbergerTestScreen2 extends StatefulWidget {
  const FakudaUnterbergerTestScreen2({super.key});

  @override
  State<FakudaUnterbergerTestScreen2> createState() => _FakudaUnterbergerTestScreen2State();
}

class _FakudaUnterbergerTestScreen2State extends State<FakudaUnterbergerTestScreen2> {
  File? galleryFile;
  final picker = ImagePicker(); 
  @override
  Widget build(BuildContext context) {
    return Scaffold(
            appBar:  AppBar(
        title: Text('MEDICLEAR',style: GoogleFonts.poppins(fontSize: 24,fontWeight: FontWeight.bold,color: Colors.black),),
        backgroundColor: Colors.white,
          automaticallyImplyLeading: false,
           leading: IconButton(onPressed:() {
                          
            Navigator.pop(context);
          }, icon:Icon(Icons.navigate_before,color: Colors.black,size: 35,)),
        centerTitle: true,
        elevation: 2,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 20,bottom: 10),
              child: Text("Upload Video Here",style: TextStyle(fontWeight: FontWeight.bold,fontSize:22, color: Coloors.fontcolor),textAlign: TextAlign.center,),
            ),
             const SizedBox( 
                  height: 20, 
                ),
                VideoRecoreder1(), 
              
                SizedBox(
                  height: 20,
                ),
                Container(
                  width: 110,
                  child: ElevatedButton(onPressed:() {
                   Navigator.of(context).push(MaterialPageRoute(builder:(context) => VertigoTest(val6:1),));
                  },
                  style: ElevatedButton.styleFrom(
                    
                    backgroundColor: Coloors.fontcolor
                  ), 
                  child:Text("Submit")),
                )
                
               
           
          ],
        ),
      ),
      
    );
  }
   
  
  
}
class VideoRecoreder1 extends StatefulWidget {
  const VideoRecoreder1({super.key});

  @override
  State<VideoRecoreder1> createState() => _VideoRecoreder1State();
}

class _VideoRecoreder1State extends State<VideoRecoreder1> {
   File? galleryFile;
  final picker = ImagePicker(); 
  @override
  Widget build(BuildContext context) {
    return  Column(
        children: [
         
           const SizedBox( 
                height: 20, 
              ), 
              SizedBox( 
               // height: 200.0, 
               
                child: galleryFile == null 
                    ?  Center(child: Container(
                      height: 200,
                      child: Image.asset("assets/upload_video.png"))) 
                    : Center(child: Text("Uploded Sucessfully")), 
              ), 
          ElevatedButton( 
                style: ButtonStyle( 
                    backgroundColor: MaterialStateProperty.all(Colors.green)), 
                child:  Text('Upload video',style:  GoogleFonts.roboto( color: Colors.white),), 
                onPressed: () { 

                  _showPicker1(context: context); 
                 
                }, 
              ), 
             
         
        ],
    
      
    );
  }
    void _showPicker1({ 
    required BuildContext context, 
  }) { 
    showModalBottomSheet( 
      context: context, 
      builder: (BuildContext context) { 
        return SafeArea( 
          child: Wrap( 
            children: <Widget>[ 
              ListTile( 
                leading: const Icon(Icons.photo_library), 
                title: const Text('Gallery'), 
                onTap: () { 
                  getVideo(ImageSource.gallery); 
                 Navigator.of(context).pop(); 
                }, 
              ), 
              ListTile( 
                leading: const Icon(Icons.photo_camera), 
                title: const Text('Camera'), 
                onTap: () { 
                  getVideo(ImageSource.camera); 
                  Navigator.of(context).pop(); 
                }, 
              ), 
            ], 
          ), 
        ); 
      }, 
    ); 
  } 
    
  
  Future getVideo( 
    ImageSource img,
  
  ) async { 
    final pickedFile = await picker.pickVideo( 
        source: img, 
        preferredCameraDevice: CameraDevice.front, 
        maxDuration: const Duration(seconds: 30)); 
    XFile? xfilePick = pickedFile; 
    setState( 
      () { 
        if (xfilePick != null) { 
          galleryFile = File(pickedFile!.path); 
          
        } else { 
          ScaffoldMessenger.of(context).showSnackBar(// is this context <<< 
              const SnackBar(content: Text('Please upload a video'))); 
        } 
      }, 
    ); 
}
}
