import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mediclear_labs/constants/colors.dart';
import 'package:mediclear_labs/screens/hearing_test/screens/vertigo_test.dart';
import 'package:mediclear_labs/screens/hearing_test/widgets/graph.dart';

class HearingTestGraphSCreen extends StatefulWidget {
  @override
  State<HearingTestGraphSCreen> createState() => _HearingTestGraphSCreenState();
}

class _HearingTestGraphSCreenState extends State<HearingTestGraphSCreen> {
  @override
  Widget build(BuildContext context) {
    // Set landscape orientation
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);

    return WillPopScope(

     
      child: Scaffold(
          appBar: AppBar(
            title: Text(
              'Hear Test',
            ),
            automaticallyImplyLeading: false,
             leading: IconButton(onPressed:() {
                                    SystemChrome.setPreferredOrientations([
                DeviceOrientation.portraitUp,
                DeviceOrientation.portraitDown,
              ]);
              Navigator.pop(context);
            }, icon:Icon(Icons.navigate_before,color: Colors.black,size: 35,)),
            backgroundColor: Coloors.fontcolor,
            actions: [IconButton(onPressed: () {
    
    
            }, icon: Icon(Icons.menu))],
          ),
          body: Row(
            children: [
              Container(
                width: 470,
                child: HearingGrapgh(),
              ),
              // SizedBox(
              //   width: 20,
              // ),
              Container(
                width: 250,
                child: Column(
                  children: [
                    RadioExample(),
                    CustomGraphButton("I CAN HEAR", 200),
                    SizedBox(
                      height: 15,
                    ),
                    CustomGraphButton("I CANNOT HEAR", 200),
                    SizedBox(
                      height: 15,
                    ),
                    CustomGraphButton(" BARELY AUDIBLE", 200),
                    SizedBox(
                      height: 15,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CustomGraphButton(">>", 95),
                        SizedBox(
                          width: 10,
                        ),
                        Container(
                          height: 45,
                          width: 95,
                          child: ElevatedButton(
                              onPressed: () {
                                 SystemChrome.setPreferredOrientations([
                DeviceOrientation.portraitUp,
                DeviceOrientation.portraitDown,
              ]);
                           Navigator.of(context).push(MaterialPageRoute(builder:(context) => VertigoTest(val4:1),));
                              },
                              style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.grey.shade400),
                              child: Text(
                                "Done",
                                style:
                                    GoogleFonts.roboto(color: Coloors.fontcolor),
                              )),
                        ),
                      ],
                    )
                  ],
                ),
              )
            ],
          )),
           onWillPop: () async{ 
             SystemChrome.setPreferredOrientations([
                DeviceOrientation.portraitUp,
                DeviceOrientation.portraitDown,
              ]);
              Navigator.pop(context);
              return true;
       },
    );
  }
}

enum SingingCharacter { left, right }

class RadioExample extends StatefulWidget {
  const RadioExample({super.key});

  @override
  State<RadioExample> createState() => _RadioExampleState();
}

class _RadioExampleState extends State<RadioExample> {
  SingingCharacter? _character = SingingCharacter.left;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 22),
      child: Row(
        children: [
          Text("Left"),
          Radio<SingingCharacter>(
            value: SingingCharacter.left,
            groupValue: _character,
            onChanged: (SingingCharacter? value) {
              setState(() {
                _character = value;
              });
            },
          ),
          SizedBox(
            width: 60,
          ),
          Text("Right"),
          Radio<SingingCharacter>(
            value: SingingCharacter.right,
            groupValue: _character,
            onChanged: (SingingCharacter? value) {
              setState(() {
                _character = value;
              });
            },
          ),
        ],
      ),
    );
  }
}

Widget CustomGraphButton(String text, double width) {
  return Container(
    height: 45,
    width: width,
    child: ElevatedButton(
        onPressed: () {},
        style: ElevatedButton.styleFrom(backgroundColor: Colors.grey.shade400),
        child: Text(
          text,
          style: GoogleFonts.roboto(color: Coloors.fontcolor),
        )),
  );
}
