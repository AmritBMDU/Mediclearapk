import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mediclear_labs/constants/colors.dart';
import 'package:mediclear_labs/main.dart';
import 'package:mediclear_labs/screens/BPPV_test/bppv_testscreen1.dart';
import 'package:mediclear_labs/screens/Eyes_test/screens/eye_test_creen1.dart';
import 'package:mediclear_labs/screens/blood_pressure_test/Screens/blood_pressure_test.dart';
import 'package:mediclear_labs/screens/fakuda_unterberger_test/screens/fakuda_unterberger_test_screen1.dart';
import 'package:mediclear_labs/screens/flat_foot_test/flat_foot_test_screen1.dart';
import 'package:mediclear_labs/screens/hearing_test/screens/home_screen.dart';
import 'package:mediclear_labs/screens/hearing_test/screens/test_screen1.dart';
import 'package:mediclear_labs/screens/login_page/login_toggle_button.dart';
import 'package:mediclear_labs/screens/romberg._test/romber_test_screen1.dart';
import 'package:mediclear_labs/screens/test_options.dart';
import 'package:mediclear_labs/screens/vng_test/screens/vng_test_screen1.dart';
import 'package:mediclear_labs/widgets/custom_text_button.dart';

class VertigoTest extends StatefulWidget {
 VertigoTest({super.key,this.val1,this.val2,this.val3,this.val4,this.val5,this.val6,this.val7,this.val8});
 // late String name;
 int? val1;
 int? val2;
 int? val3;
 int ? val4;
 int? val5;
 int? val6;
 int? val7;
 int? val8;

  @override
  State<VertigoTest> createState() => _VertigoTestState();
}

class _VertigoTestState extends State<VertigoTest> {
 
  @override
  Widget build(BuildContext context) {
    print(widget.val1);
    return Scaffold(
      appBar: AppBar(
          iconTheme: IconThemeData(color: Colors.black),
          automaticallyImplyLeading: false,
          leading: IconButton(onPressed: (){

                     Navigator.push(context, MaterialPageRoute(builder: (context)=>TestScreen()));
                    //  Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>mainPage()));
                  }, icon:Icon(Icons.navigate_before,color: Colors.black,size: 35,)),
        centerTitle: true,
        title:Text("MEDICLEAR",style: GoogleFonts.roboto(color: Coloors.fontcolor,fontWeight: FontWeight.bold, fontSize: 25),),
        backgroundColor: Colors.white,
        toolbarHeight: 70,
        actions: [
          Image.asset("assets/mediclear.jpg"),
        ],
      ),
    body: SingleChildScrollView(
      child: Column(
       
         children: [
          SizedBox(
            height: 20,
          ),
      
         CarouselSlider(items:itemList, 
         
         options:CarouselOptions( 
                height: 170.0, 
                enlargeCenterPage: true, 
                autoPlay: true, 
              //  aspectRatio: 16 / 9, 
                autoPlayCurve: Curves.fastOutSlowIn, 
                enableInfiniteScroll: true, 
                autoPlayAnimationDuration: Duration(milliseconds: 800), 
               // viewportFraction: 1, 
              ),  ),
              SizedBox(
                height: 20,
              ),
           Text("Please Select AnyOne of the test",style: GoogleFonts.roboto(fontSize: 22,color: Coloors.fontcolor),),
             SizedBox(
                height: 20,
              ),
            widget.val2==null?
          CustomTextButton(text: "Check for Blood pressure & Pulse",colorr: Colors.white, onTap:() {
          Navigator.pushReplacement(
  context,
  MaterialPageRoute(builder: (context) => BloodPressureTestCreen1()),
);
          },):CustomTextButton(text: "Check for Blood pressure & Pulse",colorr: Colors.grey ,onTap:() {
            Navigator.pushReplacement(context,MaterialPageRoute(builder:(context) => BloodPressureTestCreen1(),));
          },),
    
          //  Container(
          //   width: 280,
          //    child: CustomTextButton(text: "Measure Height", onTap:() {
              
          //          },),
          //  ),
           widget.val5==null?
           Container(
            width: 280,
            child: CustomTextButton(text: "Romberg Test", onTap:() {
              Navigator.pushReplacement(context,MaterialPageRoute(builder:(context) => RomberTestScreen1(),));
            },),
          ):  Container(
            width: 280,
            child: CustomTextButton(text: "Romberg Test", colorr: Colors.grey,onTap:() {
              Navigator.pushReplacement(context,MaterialPageRoute(builder:(context) => RomberTestScreen1(),));
            },),
          ),

          widget.val1==null?
          Container(
            width: 280,
            child: CustomTextButton(text: "Eyes Checkup",colorr: Colors.white, onTap:() {
              Navigator.pushReplacement(
  context,
  MaterialPageRoute(builder: (context) => EyeTestScreen1()),
);
            },),
          ): Container(
            width: 280,
            child: CustomTextButton(text: "Eyes Checkup",colorr: Colors.grey, onTap:() {
              
               Navigator.pushReplacement(context, MaterialPageRoute(builder:(context) => EyeTestScreen1(),));
            },),
          ),
     widget.val4==null?
          Container(
            width: 280,
            child: CustomTextButton(text: "Hearing Test", onTap:() {
                Navigator.pushReplacement(context,
                              MaterialPageRoute(builder: (context) => IndicatorWithScreens()),
                              );
                       
              
            },),
          ):Container(
            width: 280,
            child: CustomTextButton(text: "Hearing Test",colorr: Colors.grey,onTap:() {
              setState(() {
                
              });
                Navigator.pushReplacement(context,
                              MaterialPageRoute(builder: (context) => IndicatorWithScreens()),
                              );
                       
              
            },),
          ),

      
            widget.val3==null?
             Container(
            width: 280,
            child: CustomTextButton(text: "FlatFoot Test", colorr: Colors.white,onTap:() {
              Navigator.pushReplacement(context, MaterialPageRoute(builder:(context) => FlatFootTestScreen1(),));
            },),
          ):  Container(
            width: 280,
            child: CustomTextButton(text: "FlatFoot Test", colorr: Colors.grey,onTap:() {
              Navigator.pushReplacement(context, MaterialPageRoute(builder:(context) => FlatFootTestScreen1(),));
            },),
          ),
             widget.val8==null?
             Container(
            width: 280,
            child: CustomTextButton(text: "BPPV", colorr: Colors.white,onTap:() {
              Navigator.pushReplacement(context, MaterialPageRoute(builder:(context) => BppvTestScreen1(),));
            },),
          ):  Container(
            width: 280,
            child: CustomTextButton(text: "BPPV", colorr: Colors.grey,onTap:() {
              Navigator.pushReplacement(context, MaterialPageRoute(builder:(context) => BppvTestScreen1(),));
            },),
          ),

          //   widget.val4==null?
          // Container(
          //   width: 280,
          //   child: CustomTextButton(text: "Hearing Test", onTap:() {
          //       Navigator.pushReplacement(context,
          //                     MaterialPageRoute(builder: (context) => IndicatorWithScreens()),
          //                     );
                       
              
          //   },),
          // ):Container(
          //   width: 280,
          //   child: CustomTextButton(text: "Hearing Test",colorr: Colors.grey,onTap:() {
          //     setState(() {
                
          //     });
          //       Navigator.pushReplacement(context,
          //                     MaterialPageRoute(builder: (context) => IndicatorWithScreens()),
          //                     );
                       
              
          //   },),
          // ),


         
          //  Container(
          //   width: 280,
          //   child: CustomTextButton(text: "BPPV", onTap:() {
              
          //   },),
          // )
          //  widget.val5==null?
          //  Container(
          //   width: 280,
          //   child: CustomTextButton(text: "Romberg Test", onTap:() {
          //     Navigator.pushReplacement(context,MaterialPageRoute(builder:(context) => RomberTestScreen1(),));
          //   },),
          // ):  Container(
          //   width: 280,
          //   child: CustomTextButton(text: "Romberg Test", colorr: Colors.grey,onTap:() {
          //     Navigator.pushReplacement(context,MaterialPageRoute(builder:(context) => RomberTestScreen1(),));
          //   },),
          // ),


          widget.val6==null?
           Container(
            width: 280,
            child: CustomTextButton(text: "Fukuda-Unterberger Test", onTap:() {
              Navigator.pushReplacement(context, MaterialPageRoute(builder:(context) => FakudaUnterbergerTestScreen1(),));
            },),
          ): Container(
            width: 280,
            child: CustomTextButton(text: "Fukuda-Unterberger Test",colorr: Colors.grey, onTap:() {
              Navigator.pushReplacement(context, MaterialPageRoute(builder:(context) => FakudaUnterbergerTestScreen1(),));
            },),
          ),


          widget.val7==null?
           Container(
            width: 280,
            child: CustomTextButton(text: "Videonystagmography Test", onTap:() {
              Navigator.pushReplacement(context,MaterialPageRoute(builder:(context) => VngTestScreen1(),));
            },),
          ): Container(
            width: 280,
            child: CustomTextButton(text: "Videonystagmography Test",colorr: Colors.grey, onTap:() {
              Navigator.pushReplacement(context,MaterialPageRoute(builder:(context) => VngTestScreen1(),));
            },),
          ),
        SizedBox(height: 20,),
        
        TextButton(onPressed:(){
  showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Instructions'),
          content: SingleChildScrollView(
            child: Column(
              children: [
                Text(
                  '1. Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
                ),
                Text(
                  '2. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                ),
                Text(
                  '3. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.',
                ),
                 Text(
                  '4. Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
                ),
                Text(
                  '5. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                ),
                Text(
                  '6. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.',
                ),
                // Add more terms and conditions as needed
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Close'),
            ),
            // ElevatedButton(
            //   onPressed: () {
            //     setState(() {
            //      //  termsAccepted = true; // Set termsAccepted to true on Accept
            //     });
            //     Navigator.of(context).pop(); // Close the dialog
            //   },
            //   child: Text('Accept'),
            // ),
          ],
        );
      },
    );

        }, child:Text("Read Instructions"))
         ],  
      ),
    
    ),

    );
  }
}

final List <Widget>  itemList=[
   Card(
    shadowColor: Colors.transparent,
    elevation: 5,
     child: Container(
      decoration: BoxDecoration(
        color: Coloors.fontcolor,
        border: Border.all(color: Colors.black),
        shape: BoxShape.rectangle,
        image: DecorationImage(image:AssetImage("assets/testing1.jpg",) )
   
   
      ),
      ),
   ),
      Card(
        elevation: 5,
        child: Container(
          decoration: BoxDecoration(
        color: Coloors.fontcolor,
        border: Border.all(color: Colors.black),
        shape: BoxShape.rectangle,
        image: DecorationImage(image:AssetImage("assets/display_test.png",) )
      
      
          ),
          ),
      ),
   
   

  //Image.asset("assets/testing1.jpg",),


];