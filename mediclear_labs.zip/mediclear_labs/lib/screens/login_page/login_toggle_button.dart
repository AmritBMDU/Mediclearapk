import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mediclear_labs/constants/colors.dart';
import 'package:mediclear_labs/screens/application_form/screens/form.dart';
import 'package:mediclear_labs/screens/hearing_test/screens/vertigo_test.dart';
import 'package:mediclear_labs/screens/login_page/forgot_password.dart';
import 'package:mediclear_labs/screens/login_page/login_page1.dart';
import 'package:mediclear_labs/screens/payment_screen/upi_screen.dart';
import 'package:mediclear_labs/screens/signup_screen/signup.dart';
import 'package:mediclear_labs/screens/test_options.dart';

class LoginOptionsToggleButton extends StatefulWidget {
  const LoginOptionsToggleButton({super.key});

  @override
  State<LoginOptionsToggleButton> createState() => _LoginOptionsToggleButtonState();
}

class _LoginOptionsToggleButtonState extends State<LoginOptionsToggleButton> {
  TextEditingController phone= TextEditingController();
   TextEditingController password= TextEditingController();
   TextEditingController resourcename=TextEditingController();
   TextEditingController batchno=TextEditingController();
   TextEditingController doctorpassword=TextEditingController();
   int selectedOption=1;
  @override
  Widget build(BuildContext context) {
    
    return  SafeArea(
      child: Scaffold(
        body: SingleChildScrollView(
          child: Column(
              children: [
                // Toggle Button
                  Padding(
                    padding: const EdgeInsets.only(top: 30),
                    child: Center(
                    child: Text(
                                  "Login here ",
                                  style: GoogleFonts.poppins(
                      fontWeight: FontWeight.bold,
                      color: Coloors.fontcolor,
                      fontSize: 22),
                                )),
                  ),
                Padding(
                  padding: const EdgeInsets.only(top: 5),
                  child: Row(
                    
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('Customer Login',textAlign: TextAlign.center, style: GoogleFonts.roboto(fontWeight: FontWeight.bold,fontSize:14, color: Coloors.fontcolor),),
                     Radio(
              value: 1,
                activeColor: Coloors.fontcolor,         
              groupValue: selectedOption,
              onChanged: (value) {
                setState(() {
                  selectedOption = value!;
                });
              },
            ),
                      Text('Corperate Login',textAlign: TextAlign.center, style:GoogleFonts.roboto(fontWeight: FontWeight.bold,fontSize:14, color: Coloors.fontcolor),),
                       Radio(
               activeColor: Coloors.fontcolor,         
              value: 2,
              groupValue: selectedOption,
              onChanged: (value) {
                setState(() {
                  selectedOption = value!;
                });
              },
            ),
                    ],
                  ),
                ),
                // Content based on the selected screen
                selectedOption == 1
              ? buildScreen1Content()
              : buildScreen2Content()
              ],
            
          ),
        ),
      ),
    );
  }

  Widget buildScreen1Content() {
    // You can call any widget or UI elements for Screen 1 here
    return Padding(
        padding: const EdgeInsets.all(8.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
            
              SizedBox(
                height: 30,
              ),
              Text(
                "Welcome back you've",
                style: GoogleFonts.poppins(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                    color: Colors.black),
              ),
              Text(
                "been missed!",
                style: GoogleFonts.poppins(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                    color: Colors.black),
              ),
              SizedBox(
                height: 50,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: MyTextFormField(title: "Phone", controller: phone,),
              ),
              SizedBox(
                height: 40,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: MyTextFormField(title: "Password", controller: password,),
              ),
              SizedBox(
                height: 10,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                      onPressed: () {
                         Navigator.push(context,MaterialPageRoute(builder:(context) => ForgotPassword(),));
                      },
                      child: Text(
                        "Forgot your password?",
                        style: GoogleFonts.poppins(
                            color: Coloors.fontcolor,
                            fontWeight: FontWeight.w600),
                      ))
                ],
              ),
              SizedBox(
                height: 20,
              ),
              MyButton(
                name: "Login as Customer",
                width: 350,
                height: 48, onPressedCallback: () { 
                  Navigator.push(context, MaterialPageRoute(builder:(context) =>TestScreen(),));
                 },
              ),
              SizedBox(
                height: 25,
              ),
              
              TextButton(
                onPressed: () {
                Navigator.of(context).push(MaterialPageRoute(builder:(context) => SignUp(),));
                },
                child: Text(
                  "Create new Account",
                  style: GoogleFonts.poppins(fontWeight: FontWeight.w500,color: Coloors.fontcolor),
                ),
              ),
              SizedBox(
                height: 60,
              ),
              // Text(
              //   "Or continue with",
              //   style: GoogleFonts.poppins(
              //       color: Coloors.fontcolor,
              //       fontWeight: FontWeight.w600),
              // ),
              // SizedBox(
              //   height: 10,
              // ),
              // Row(
              //   mainAxisAlignment: MainAxisAlignment.center,
              //   children: [
              //     Container(
              //         height: 45,
              //         width: 55,
              //         decoration: BoxDecoration(
              //             color: Colors.grey.shade200,
              //             borderRadius: BorderRadius.circular(10)),
              //         child: TextButton(
              //             onPressed: () {},
              //             child: Text(
              //               "G",
              //               style: GoogleFonts.poppins(
              //                   color: Colors.black, fontSize: 20),
              //             ))),
              //     SizedBox(
              //       width: 15,
              //     ),
              //     Container(
              //       height: 45,
              //       width: 55,
              //       decoration: BoxDecoration(
              //           color: Colors.grey.shade200,
              //           borderRadius: BorderRadius.circular(10)),
              //       child: IconButton(
              //           onPressed: () {}, icon: Icon(Icons.facebook)),
              //     ),
              //     SizedBox(
              //       width: 15,
              //     ),
              //     Container(
              //       height: 45,
              //       width: 55,
              //       decoration: BoxDecoration(
              //           color: Colors.grey.shade200,
              //           borderRadius: BorderRadius.circular(10)),
              //       child:
              //           IconButton(onPressed: () {}, icon: Icon(Icons.apple)),
              //     )
              //   ],
              // )
            ],
          ),
        ),
      );
  }

  Widget buildScreen2Content() {
    // You can call any widget or UI elements for Screen 2 here
    return  Padding(
        padding: const EdgeInsets.all(8.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
            
              SizedBox(
                height: 30,
              ),
              Text(
                "Welcome back you've",
                style: GoogleFonts.poppins(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                    color: Colors.black),
              ),
              Text(
                "been missed!",
                style: GoogleFonts.poppins(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                    color: Colors.black),
              ),
              SizedBox(
                height: 50,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: MyTextFormField(title: "User id ", controller: resourcename,),
              ),
              SizedBox(
                height: 40,
              ),
          
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: MyTextFormField(title: "Password", controller: doctorpassword,),
              ),
              SizedBox(
                height: 10,
              ),
           
              SizedBox(
                height: 20,
              ),
              MyButton(
                name: "Login as Corperate",
                width: 350,
                height: 48, onPressedCallback: () {   Navigator.push(context, MaterialPageRoute(builder:(context) => MyForm(),)); },
              ),
              SizedBox(
                height: 25,
              ),
              
             
              // Text(
              //   "Or continue with",
              //   style: GoogleFonts.poppins(
              //       color: Coloors.fontcolor,
              //       fontWeight: FontWeight.w600),
              // ),
              // SizedBox(
              //   height: 10,
              // ),
              // Row(
              //   mainAxisAlignment: MainAxisAlignment.center,
              //   children: [
              //     Container(
              //         height: 45,
              //         width: 55,
              //         decoration: BoxDecoration(
              //             color: Colors.grey.shade200,
              //             borderRadius: BorderRadius.circular(10)),
              //         child: TextButton(
              //             onPressed: () {},
              //             child: Text(
              //               "G",
              //               style: GoogleFonts.poppins(
              //                   color: Colors.black, fontSize: 20),
              //             ))),
              //     SizedBox(
              //       width: 15,
              //     ),
              //     Container(
              //       height: 45,
              //       width: 55,
              //       decoration: BoxDecoration(
              //           color: Colors.grey.shade200,
              //           borderRadius: BorderRadius.circular(10)),
              //       child: IconButton(
              //           onPressed: () {}, icon: Icon(Icons.facebook)),
              //     ),
              //     SizedBox(
              //       width: 15,
              //     ),
              //     Container(
              //       height: 45,
              //       width: 55,
              //       decoration: BoxDecoration(
              //           color: Colors.grey.shade200,
              //           borderRadius: BorderRadius.circular(10)),
              //       child:
              //           IconButton(onPressed: () {}, icon: Icon(Icons.apple)),
              //     )
             //   ],
             // )
            ],
          ),
        ),
      );
  }
}

