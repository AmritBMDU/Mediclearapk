import 'dart:io';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:mediclear_labs/constants/colors.dart';
import 'package:mediclear_labs/screens/hearing_test/screens/vertigo_test.dart';

class RombergTestScreen3 extends StatefulWidget {
  const RombergTestScreen3({super.key});

  @override
  State<RombergTestScreen3> createState() => _RombergTestScreen3State();
}

class _RombergTestScreen3State extends State<RombergTestScreen3> {
   File? galleryFile;
  final picker = ImagePicker(); 
  @override
  Widget build(BuildContext context) {
    return Scaffold(
            appBar:  AppBar(
        title: Text('MEDICLEAR',style: GoogleFonts.poppins(fontSize: 24,fontWeight: FontWeight.bold,color: Colors.black),),
        backgroundColor: Colors.white,
          automaticallyImplyLeading: false,
           leading: IconButton(onPressed:() {
                          
            Navigator.pop(context);
          }, icon:Icon(Icons.navigate_before,color: Colors.black,size: 35,)),
        centerTitle: true,
        elevation: 2,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 20,bottom: 10),
              child: Text("Upload Video Here",style:  GoogleFonts.roboto(fontWeight: FontWeight.bold,fontSize:22, color: Coloors.fontcolor),textAlign: TextAlign.center,),
            ),
             const SizedBox( 
                  height: 20, 
                ),
                VideoRecoreder1(), 
                VideoRecoreder2(),
                VideoRecoreder3(),
                SizedBox(
                  height: 20,
                ),
                ElevatedButton(onPressed:() {
                   Navigator.of(context).push(MaterialPageRoute(builder:(context) => VertigoTest(val5:1),));
                },
                style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                  backgroundColor: Coloors.fontcolor
                ), 
                child:Text("Submit"))
                
               
           
          ],
        ),
      ),
      
    );
  }
   
  
  
}






class VideoRecoreder1 extends StatefulWidget {
  const VideoRecoreder1({super.key});

  @override
  State<VideoRecoreder1> createState() => _VideoRecoreder1State();
}

class _VideoRecoreder1State extends State<VideoRecoreder1> {
   File? galleryFile;
  final picker = ImagePicker(); 
  @override
  Widget build(BuildContext context) {
    return  Column(
        children: [
         
           const SizedBox( 
                height: 20, 
              ), 
              SizedBox( 
               // height: 200.0, 
               
                child: galleryFile == null 
                    ?  Center(child: Container(
                      height: 100,
                      child: Image.asset("assets/upload_video.png"))) 
                    : Center(child: Text("Uploded Sucessfully")), 
              ), 
          ElevatedButton( 
                style: ButtonStyle( 
                    backgroundColor: MaterialStateProperty.all(Colors.green)), 
                child: const Text('Standing on Both Legs',style: TextStyle(color: Colors.white),), 
                onPressed: () { 

                  _showPicker1(context: context); 
                 
                }, 
              ), 
             
         
        ],
    
      
    );
  }
    void _showPicker1({ 
    required BuildContext context, 
  }) { 
    showModalBottomSheet( 
      context: context, 
      builder: (BuildContext context) { 
        return SafeArea( 
          child: Wrap( 
            children: <Widget>[ 
              ListTile( 
                leading: const Icon(Icons.photo_library), 
                title: const Text('Gallery'), 
                onTap: () { 
                  getVideo(ImageSource.gallery); 
                 Navigator.of(context).pop(); 
                }, 
              ), 
              ListTile( 
                leading: const Icon(Icons.photo_camera), 
                title: const Text('Camera'), 
                onTap: () { 
                  getVideo(ImageSource.camera); 
                  Navigator.of(context).pop(); 
                }, 
              ), 
            ], 
          ), 
        ); 
      }, 
    ); 
  } 
    
  
  Future getVideo( 
    ImageSource img,
  
  ) async { 
    final pickedFile = await picker.pickVideo( 
        source: img, 
        preferredCameraDevice: CameraDevice.front, 
        maxDuration: const Duration(seconds: 30)); 
    XFile? xfilePick = pickedFile; 
    setState( 
      () { 
        if (xfilePick != null) { 
          galleryFile = File(pickedFile!.path); 
          
        } else { 
          ScaffoldMessenger.of(context).showSnackBar(// is this context <<< 
              const SnackBar(content: Text('Please upload a video'))); 
        } 
      }, 
    ); 
}
}

class VideoRecoreder3 extends StatefulWidget {
  const VideoRecoreder3({super.key});

  @override
  State<VideoRecoreder3> createState() => _VideoRecoreder3State();
}

class _VideoRecoreder3State extends State<VideoRecoreder3> {
   File? galleryFile;
  final picker = ImagePicker(); 
  @override
  Widget build(BuildContext context) {
    return  Column(
        children: [
         
           const SizedBox( 
                height: 20, 
              ), 
              SizedBox( 
               // height: 200.0, 
               
                child: galleryFile == null 
                    ?  Center(child:  Container(
                      height: 100,
                      child: Image.asset("assets/upload_video.png"))) 
                    : Center(child: Text("Uploded Sucessfully")), 
              ), 
          ElevatedButton( 
                style: ButtonStyle( 
                    backgroundColor: MaterialStateProperty.all(Colors.green)), 
                child: const Text('Standing on right Leg',style: TextStyle(color: Colors.white),), 
                onPressed: () { 

                  _showPicker1(context: context); 
                 
                }, 
              ), 
             
         
        ],
      
      
    );
  }
    void _showPicker1({ 
    required BuildContext context, 
  }) { 
    showModalBottomSheet( 
      context: context, 
      builder: (BuildContext context) { 
        return SafeArea( 
          child: Wrap( 
            children: <Widget>[ 
              ListTile( 
                leading: const Icon(Icons.photo_library), 
                title: const Text('Gallery'), 
                onTap: () { 
                  getVideo(ImageSource.gallery); 
                 Navigator.of(context).pop(); 
                }, 
              ), 
              ListTile( 
                leading: const Icon(Icons.photo_camera), 
                title: const Text('Camera'), 
                onTap: () { 
                  getVideo(ImageSource.camera); 
                  Navigator.of(context).pop(); 
                }, 
              ), 
            ], 
          ), 
        ); 
      }, 
    ); 
  } 
    
  
  Future getVideo( 
    ImageSource img,
  
  ) async { 
    final pickedFile = await picker.pickVideo( 
        source: img, 
        preferredCameraDevice: CameraDevice.front, 
        maxDuration: const Duration(seconds: 30)); 
    XFile? xfilePick = pickedFile; 
    setState( 
      () { 
        if (xfilePick != null) { 
          galleryFile = File(pickedFile!.path); 
          
        } else { 
          ScaffoldMessenger.of(context).showSnackBar(// is this context <<< 
              const SnackBar(content: Text('Please upload a video'))); 
        } 
      }, 
    ); 
}
}
class VideoRecoreder2 extends StatefulWidget {
  const VideoRecoreder2({super.key});

  @override
  State<VideoRecoreder2> createState() => _VideoRecoreder2State();
}

class _VideoRecoreder2State extends State<VideoRecoreder2> {
   File? galleryFile;
  final picker = ImagePicker(); 
  @override
  Widget build(BuildContext context) {
    return  Column(
        children: [
          
           const SizedBox( 
                height: 20, 
              ), 
              SizedBox( 
               // height: 200.0, 
               
                child: galleryFile == null 
                    ?  Center(child:  Container(
                      height: 100,
                      child: Image.asset("assets/upload_video.png"))) 
                    : Center(child: Text("Uploded Sucessfully")), 
              ), 
          ElevatedButton( 
                style: ButtonStyle( 
                    backgroundColor: MaterialStateProperty.all(Colors.green)), 
                child: const Text('Standing on Left Leg'), 
                onPressed: () { 

                  _showPicker1(context: context); 
                 
                }, 
              ), 
             
         
        ],
      
      
    );
  }
    void _showPicker1({ 
    required BuildContext context, 
  }) { 
    showModalBottomSheet( 
      context: context, 
      builder: (BuildContext context) { 
        return SafeArea( 
          child: Wrap( 
            children: <Widget>[ 
              ListTile( 
                leading: const Icon(Icons.photo_library), 
                title: const Text('Gallery'), 
                onTap: () { 
                  getVideo(ImageSource.gallery); 
                 Navigator.of(context).pop(); 
                }, 
              ), 
              ListTile( 
                leading: const Icon(Icons.photo_camera), 
                title: const Text('Camera'), 
                onTap: () { 
                  getVideo(ImageSource.camera); 
                  Navigator.of(context).pop(); 
                }, 
              ), 
            ], 
          ), 
        ); 
      }, 
    ); 
  } 
    
  
  Future getVideo( 
    ImageSource img,
  
  ) async { 
    final pickedFile = await picker.pickVideo( 
        source: img, 
        preferredCameraDevice: CameraDevice.front, 
        maxDuration: const Duration(seconds: 30)); 
    XFile? xfilePick = pickedFile; 
    setState( 
      () { 
        if (xfilePick != null) { 
          galleryFile = File(pickedFile!.path); 
          
        } else { 
          ScaffoldMessenger.of(context).showSnackBar(// is this context <<< 
              const SnackBar(content: Text('Please upload a video'))); 
        } 
      }, 
    ); 
}
}