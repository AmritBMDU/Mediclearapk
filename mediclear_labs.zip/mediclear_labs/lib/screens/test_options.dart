import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mediclear_labs/constants/colors.dart';
import 'package:mediclear_labs/screens/application_form/screens/form.dart';
import 'package:mediclear_labs/screens/hearing_test/screens/vertigo_test.dart';
import 'package:mediclear_labs/widgets.dart/custom_text_button.dart';

class TestScreen extends StatelessWidget {
  const TestScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
     
      appBar: AppBar(
        backgroundColor: Colors.white,
        centerTitle: true,
       title: Text("MEDICLEAR",style:  GoogleFonts.roboto(fontSize: 24 ,color: Coloors.fontcolor,fontWeight: FontWeight.bold),),

      ),
      body: Column(
        children: [
          Card(
            elevation: 5,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
            child: Image.asset("assets/display_test.png")),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 20),
                child: Text("Available Test:",style:  GoogleFonts.roboto(color: Colors.black,fontSize: 20),),
              ),
            
            Container(
              width: 250,
              child: CustomTextButton(text: "Vertigo", onTap:() {
                Navigator.of(context).push(MaterialPageRoute(builder:(context) => MyForm(),));
                
              },),
            ),
              Container(
                width: 250,
                child: CustomTextButton(text: "FirstAid Training", onTap:() {
                  
                },),
              ),
            Container(
              width: 250,
              child: CustomTextButton(text: "Coorperate Testing", onTap:() {
                
              },),
            ),
            
              Container(
                width: 250,
                child: CustomTextButton(text: "Telecommunication Testing ", onTap:() {
                  
                },),
              )

        ],
      ),
    );
  }
}