import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mediclear_labs/constants/colors.dart';
import 'package:mediclear_labs/screens/application_form/screens/form.dart';
import 'package:mediclear_labs/screens/hearing_test/screens/vertigo_test.dart';
import 'package:mediclear_labs/screens/login_page/login_toggle_button.dart';
import 'package:mediclear_labs/widgets/custom_text_button.dart';
import 'package:mediclear_labs/widgets/drawer/feedback.dart';
import 'package:mediclear_labs/widgets/drawer/payment_history.dart';
import 'package:mediclear_labs/widgets/drawer/reset_password.dart';
import 'package:mediclear_labs/widgets/drawer/test_history.dart';
import 'package:mediclear_labs/widgets/drawer/user_profile.dart';
import 'package:mediclear_labs/widgets/legal.dart';

class TestScreen extends StatelessWidget {
  const TestScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
     
      appBar: AppBar(
        backgroundColor: Colors.white,
        centerTitle: true,
       title: Text("MEDICLEAR",style:  GoogleFonts.roboto(fontSize: 24 ,color: Coloors.fontcolor,fontWeight: FontWeight.bold),),

      ),
       drawer:Drawer(
        
       child: ListView(
        // Important: Remove any padding from the ListView.
        padding: EdgeInsets.zero,
        children: [
          SizedBox(
            height: 30,
          ),
           Padding(
             padding: const EdgeInsets.symmetric(vertical: 20,horizontal: 10),
             child: InkWell(
              onTap: (){
                Navigator.push(context, MaterialPageRoute(builder:(BuildContext context)=>User_Profile()));
              },
               child: Container(
                height: 100,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15),
                  color: Coloors.fontcolor
               
                ),
                  child:Padding(
                    padding: const EdgeInsets.only(left: 10),
                    child: Row(crossAxisAlignment: CrossAxisAlignment.center,
                    
                      children: [
                       CircleAvatar(
                            radius: 25,
                            child: Text("SB"),
                            backgroundColor: Colors.grey,
                            
                          ),
                          SizedBox(width: 20,),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                             Text("Hi,Saurabh",style: GoogleFonts.poppins(fontWeight: FontWeight.w400,fontSize: 16,color:Colors.white),),
                             Text("Logged in via 8979034037",style: GoogleFonts.poppins(fontSize: 12,color: Colors.white),) 
                            ],
                          ),
                         
                      ],
                    ),
                  )
                         ),
             ),
             
           ),
       listTile(
                    title: 'Home',
                    icon: Icons.home,
                    callback: (){

                     Navigator.push(context, MaterialPageRoute(builder: (context)=>VertigoTest()));
                    }
                ),
              
          
              listTile(
                  title: ' Test History',
                  icon: Icons.history_outlined,
                  callback: (){
                   Navigator.push(context, MaterialPageRoute(builder: (context)=>TextHistory()));
                  }
              ),
               listTile(
                  title: ' Payment History',
                  icon: Icons.payment_outlined,
                  callback: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>PaymentHistory()));
                  }
              ),
            
              listTile(
                  title: 'Complain & feedback',
                  icon: Icons.message_outlined,
                  callback: (){
                  Navigator.push(context, MaterialPageRoute(builder:(context) => FeedBack(),));
                  }
              ),
              listTile(
                title: 'Reset Password',
                  icon: Icons.password_outlined,
                callback: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>reset_password()));
                }
              ),
             
              listTile(
                title:"Terms & Conditions",
                icon: (Icons.report) ,
                callback: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>termsandCondition()));
                },
              ),
              
              Divider(
                height: 2,
                color: Colors.grey.shade400,
              ),
              listTile(
                  title: 'Logout',
                  icon: Icons.logout_outlined,
                  callback: (){

                      showDialog(
                          context: context,
                          builder: (context){
                            return AlertDialog(
                              title: Text('Alert'),
                              content: Text('Are you sure exit?'),
                              actions: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  children: [
                                    ElevatedButton(onPressed: (){
                                 Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>LoginOptionsToggleButton()));
                                    
                                    }, 
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Coloors.fontcolor
                                    ),
                                    child: Text('Yes')),
                                    ElevatedButton(onPressed: (){
                                      Navigator.pop(context);
                                    }, 
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Coloors.fontcolor
                                    ),
                                    child: Text('No')),
                                  ],
                                )
                              ],
                            );
                          });
                    //  Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>mainPage()));
                  }
              ),
        
        ],
      ),
      
    
    ),
      body: Column(
        children: [
          Card(
            elevation: 5,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
            child: Image.asset("assets/display_test.png")),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 20),
                child: Text("Available Test:",style:  GoogleFonts.roboto(color: Colors.black,fontSize: 20),),
              ),
            
            Container(
              width: 250,
              child: CustomTextButton(text: "Vertigo", onTap:() {
                Navigator.of(context).push(MaterialPageRoute(builder:(context) => MyForm(),));
                
              },),
            ),
              Container(
                width: 250,
                child: CustomTextButton(text: "FirstAid Training", onTap:() {
                  
                },),
              ),
            Container(
              width: 250,
              child: CustomTextButton(text: "Coorperate Testing", onTap:() {
                
              },),
            ),
            
              Container(
                width: 250,
                child: CustomTextButton(text: "Telecommunication Testing ", onTap:() {
                  
                },),
              )

        ],
      ),
    );
  }
}