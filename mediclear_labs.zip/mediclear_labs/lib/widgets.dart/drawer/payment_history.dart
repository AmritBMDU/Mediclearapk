
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mediclear_labs/constants/colors.dart';



class PaymentHistory extends StatefulWidget {
  const PaymentHistory({super.key});

  @override
  State<PaymentHistory> createState() => _Report_block();
}
class _Report_block extends State<PaymentHistory> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
         appBar: AppBar(
        title: Text("Payment History",style: GoogleFonts.poppins(),),
        backgroundColor: Coloors.fontcolor,
        centerTitle: true,
        elevation: 5,
        ),
        resizeToAvoidBottomInset: false,
        // endDrawer: Drawers(context),
        body: Center(
          child: Image.asset('assets/NodataFound.png'),
        )
    );

  }


}




