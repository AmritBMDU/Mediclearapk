
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mediclear_labs/constants/colors.dart';



class TestHistory extends StatefulWidget {
  const TestHistory({super.key});

  @override
  State<TestHistory> createState() => _Report_block();
}
class _Report_block extends State<TestHistory> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
         appBar: AppBar(
        title: Text("Test History",style: GoogleFonts.poppins(),),
        backgroundColor: Coloors.fontcolor,
        centerTitle: true,
        elevation: 5,
        ),
        resizeToAvoidBottomInset: false,
        // endDrawer: Drawers(context),
        body: Center(
          child: Image.asset('assets/NodataFound.png'),
        )
    );

  }


}




