
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:mediclear_labs/constants/colors.dart';



class User_Profile extends StatefulWidget {
  const User_Profile({super.key});

  @override
  State<User_Profile> createState() => _User_Profile();
}
class _User_Profile extends State<User_Profile> {
  File? SelectedImage;

  @override
  Widget build(BuildContext context) {
  
    var size = MediaQuery.of(context).size;
    return Scaffold(
        appBar: AppBar(automaticallyImplyLeading: true,
          centerTitle: true,
          leading: IconButton(onPressed: (){
            Navigator.pop(context);
          },icon: Icon(Icons.arrow_back,color:Colors.black,),),
          title: Text('Profile ',style: TextStyle(fontWeight: FontWeight.w500,color: Coloors.fontcolor),),
        ),
        resizeToAvoidBottomInset: false,
        // endDrawer: Drawers(context),
        body:Column(
          children: [
            SizedBox(height: 30,),
            Center(
              child: Stack(
                  children:[
                    CircleAvatar(
                      radius: 50,
                       backgroundImage:  AssetImage('assets/eye_icon1.png'),
                      child: SelectedImage != null ? Image.file(SelectedImage!):Icon(Icons.person),
                      // backgroundImage: SelectedImage ==null ? Image(image: Image.file(SelectedImage!),): NetworkImage(),
                    ),
                    Positioned(
                        top: 60,
                        left: 60,
                        child: CircleAvatar(
                          radius: 20,
                          backgroundColor: Coloors.fontcolor,
                          child: Center(
                            child: IconButton(
                              onPressed: (){
                                  showModalBottomSheet<void>(
                                  context: context,
                                  builder: (BuildContext context) {
                                    return Container(
                                      height: 80,
                                      color:Coloors.fontcolor,
                                      child: Center(
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          mainAxisSize: MainAxisSize.min,
                                          children: <Widget>[
                                            Column(
                                              children: [
                                                IconButton(onPressed: (){
                                                  imagePickerCamera();
                                                }, icon: Icon(Icons.camera,color: Colors.white,),
                                                ),
                                                Text('Camera',style: TextStyle(color: Colors.white),),

                                              ],
                                            ),
                                            SizedBox(width: 40,),
                                            Column(
                                              children: [
                                                IconButton(onPressed: (){
                                                  imagePicker();
                                                }, icon: FaIcon(FontAwesomeIcons.file,color: Colors.white,),
                                                ),
                                                Text('File',style: TextStyle(color: Colors.white),),
                                              ],
                                            ),

                                            // ElevatedButton(
                                            //   child: const Text('Close BottomSheet'),
                                            //   onPressed: () => Navigator.pop(context),
                                            // ),
                                          ],
                                        ),
                                      ),
                                    );
                                  },
                                );
                              },icon: Icon(Icons.camera_alt,color: Colors.white,),
                            ),
                          ),
                        ))
                  ]
              ),

            ),
            SizedBox(height: 10,),
            Padding(
              padding: const EdgeInsets.only(left: 20,right: 20),
              child: Container(
                height: size.height * 0.06,
                child: TextField(
                    keyboardType: TextInputType.visiblePassword,
                    decoration: InputDecoration(
                      hintText: 'Saurabh',
                      fillColor: Color(0xfff1f3ff
                      ),
                      suffixIcon: Icon(Icons.person),
                      contentPadding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(11),
                          ),
                          borderSide: BorderSide(color: Colors.grey)
                      ),
                      focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Color(0xff1f42ba),
                          ),
                          borderRadius: BorderRadius.all(Radius.circular(11))
                      ),
                    )
                ),
              ),
            ),
            SizedBox(height: 10,),
            Padding(
              padding: const EdgeInsets.only(left: 20,right: 20),
              child: Container(
                height: size.height * 0.06,
                child: TextField(
                    keyboardType: TextInputType.visiblePassword,
                    decoration: InputDecoration(
                      hintText: 'Baghel',
                      fillColor: Color(0xfff1f3ff
                      ),
                      suffixIcon: Icon(Icons.person),
                      contentPadding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(11),
                          ),
                          borderSide: BorderSide(color: Colors.grey)
                      ),
                      focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Color(0xff1f42ba),
                          ),
                          borderRadius: BorderRadius.all(Radius.circular(11))
                      ),
                    )
                ),
              ),
            ),
            SizedBox(height: 10,),
            Padding(
              padding: const EdgeInsets.only(left: 20,right: 20),
              child: Container(
                height: size.height * 0.06,
                child: TextField(
                    keyboardType: TextInputType.visiblePassword,
                    decoration: InputDecoration(
                      hintText: '+91 8979034037',
                      fillColor: Color(0xfff1f3ff
                      ),
                      suffixIcon: Icon(Icons.phone_android),
                      contentPadding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(11),
                          ),
                          borderSide: BorderSide(color: Colors.grey)
                      ),
                      focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Color(0xff1f42ba),
                          ),
                          borderRadius: BorderRadius.all(Radius.circular(11))
                      ),
                    )
                ),
              ),
            ),
            SizedBox(height: 10,),
            Padding(
              padding: const EdgeInsets.only(left: 20,right: 20),
              child: Container(
                height: size.height * 0.06,
                child: TextField(
                    keyboardType: TextInputType.visiblePassword,
                    decoration: InputDecoration(
                      hintText: 'Email',
                      fillColor: Color(0xfff1f3ff
                      ),
                      suffixIcon: Icon(Icons.email),
                      contentPadding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(11),
                          ),
                          borderSide: BorderSide(color: Colors.grey)
                      ),
                      focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Color(0xff1f42ba),
                          ),
                          borderRadius: BorderRadius.all(Radius.circular(11))
                      ),
                    )
                ),
              ),
            ),
            SizedBox(height: 10,),
            Padding(
              padding: const EdgeInsets.only(left: 20,right: 20),
              child: Container(
                height: size.height * 0.06,
                child: TextField(
                    keyboardType: TextInputType.visiblePassword,
                    decoration: InputDecoration(
                      hintText: 'City',
                      fillColor: Color(0xfff1f3ff
                      ),
                      suffixIcon: Icon(Icons.location_city),
                      contentPadding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(11),
                          ),
                          borderSide: BorderSide(color: Colors.grey)
                      ),
                      focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Color(0xff1f42ba),
                          ),
                          borderRadius: BorderRadius.all(Radius.circular(11))
                      ),
                    )
                ),
              ),
            ),
            SizedBox(height: 10,),
            Padding(
              padding: const EdgeInsets.only(left: 20,right: 20),
              child: Container(
                height: size.height * 0.06,
                child: TextField(
                    keyboardType: TextInputType.visiblePassword,
                    decoration: InputDecoration(
                      hintText: 'State',
                      fillColor: Color(0xfff1f3ff
                      ),
                      suffixIcon: Icon(Icons.location_on),
                      contentPadding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(11),
                          ),
                          borderSide: BorderSide(color: Colors.grey)
                      ),
                      focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Color(0xff1f42ba),
                          ),
                          borderRadius: BorderRadius.all(Radius.circular(11))
                      ),
                    )
                ),
              ),
            ),
            SizedBox(height: 10,),
            SizedBox(
              width: MediaQuery.of(context).size.width * 0.89,
              child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      shape: BeveledRectangleBorder(
                          borderRadius: BorderRadius.all(Radius.circular(3))
                      ),
                      backgroundColor: Coloors.fontcolor
                  ),
                  onPressed: (){
                   // Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=> MainPage()));
                  }, child: Text('Update',style: TextStyle(fontSize: 20,fontWeight: FontWeight.w300,color: Colors.white),)),
            ),
          ],
        )
    );

  }
  Future imagePicker()async{
    final returnedImage = await ImagePicker().pickImage(source: ImageSource.gallery);

    // Cropped Image
    CroppedFile? croppedFile = await ImageCropper().cropImage(sourcePath: returnedImage!.path

    );
    if(returnedImage == null)return;
    setState(() {
      SelectedImage = File(croppedFile!.path);
      Navigator.of(context).pop();
    });
  }
  Future imagePickerCamera()async{
    final returnedImage = await ImagePicker().pickImage(source: ImageSource.camera);
    CroppedFile? croppedFile = await ImageCropper().cropImage(
        aspectRatioPresets: [
          CropAspectRatioPreset.square,
          CropAspectRatioPreset.ratio3x2,
          CropAspectRatioPreset.original,
          CropAspectRatioPreset.ratio4x3,
          CropAspectRatioPreset.ratio16x9,
        ],
        sourcePath: returnedImage!.path
    );
    if(returnedImage == null)return;
    setState(() {
      SelectedImage = File(croppedFile!.path);
      Navigator.of(context).pop();

    });
  }

}




